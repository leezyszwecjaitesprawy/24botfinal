const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    init(client) {
        // Initialize any necessary state or data
        console.log('Rules component initialized');
    },
    
    /**
     * Create a rules embed with accept button
     * @param {Object} options - Options for the rules
     * @param {String} options.title - Title of the rules embed
     * @param {String} options.description - Description/content of the rules
     * @param {String} options.buttonLabel - Label for the accept button
     * @returns {Object} - The embed and components for the rules message
     */
    createRulesEmbed(options = {}) {
        // Set default values
        const title = options.title || 'Server Rules';
        const description = options.description || 'Please read and accept the server rules.';
        const buttonLabel = options.buttonLabel || 'Accept Rules';
        const roleId = options.roleId || null;
        
        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle(title)
            .setDescription(description)
            .setTimestamp()
            .setFooter({ text: '24BOT Rules System' });
        
        // Create the accept button
        const acceptButton = new ButtonBuilder()
            .setCustomId(`rules:accept:${roleId || 'no-role'}`)
            .setLabel(buttonLabel)
            .setStyle(ButtonStyle.Success);
        
        // Add the button to an action row
        const row = new ActionRowBuilder().addComponents(acceptButton);
        
        return {
            embeds: [embed],
            components: [row]
        };
    },
    
    /**
     * Handle the rules accept button interaction
     * @param {Object} interaction - The button interaction
     * @param {Object} client - The Discord client
     * @param {Array} args - Additional arguments from the custom ID
     */
    async handleButton(interaction, client, args) {
        try {
            // Get the action from args
            const action = args[0];
            
            if (action === 'accept') {
                // Get the role ID from args
                const roleId = args[1];
                
                // If a valid role ID is provided, assign the role
                if (roleId && roleId !== 'no-role') {
                    const role = interaction.guild.roles.cache.get(roleId);
                    
                    if (role) {
                        await interaction.member.roles.add(role);
                        await interaction.reply({
                            content: `You have accepted the rules`,
                            ephemeral: true
                        });
                    } else {
                        await interaction.reply({
                            content: 'You have accepted the rules',
                            ephemeral: true
                        });
                    }
                } else {
                    await interaction.reply({
                        content: 'You have accepted the rules',
                        ephemeral: true
                    });
                }
            }
        } catch (error) {
            console.error('Error handling rules button:', error);
            
            // Reply with a generic error message
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: 'There was an error processing your interaction.',
                    ephemeral: true
                });
            }
        }
    }
};