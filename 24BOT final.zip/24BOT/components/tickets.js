const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionFlagsBits,
    ChannelType
} = require('discord.js');
const logger = require('../utils/logger');

// Track ticket counters
let ticketCounter = Math.floor(Date.now() / 1000);
const TICKET_CATEGORIES = [
    'Proposition',
    'Support',
    'Mixing & Mastering services',
    'Purchase a license',
    'Other'
];

module.exports = {
    init(client) {
        // Initialize any necessary state or data
        console.log('Tickets component initialized');
    },

    /**
     * Create a ticket panel with category selection
     * @param {Object} options - Options for the ticket panel
     * @param {String} options.title - Title of the ticket panel
     * @param {String} options.description - Description of the ticket panel
     * @param {Array} options.categories - Array of category names
     * @param {String|Number} options.color - Color for the ticket panel embed (hex string or integer)
     * @returns {Object} - The embed and components for the ticket panel
     */
    createTicketPanel(options = {}) {
        // Set default values
        const title = options.title || 'TICKETS';
        const description = options.description || 'Sellect a category below to create a ticket\n<@&1141712746417762359> will respond as soon as possible\n\n**Available categories:**\n> - Proposition\n> - Support\n> - Mixing & Mastering services\n> - Purchase a license\n> - Other\nSellect a category from the dropdown menu below';
        const categories = options.categories || TICKET_CATEGORIES;

        // Process color - convert hex to integer if needed
        let color = 0x808080; // Default dark gray color
        if (options.color) {
            if (typeof options.color === 'string' && options.color.startsWith('#')) {
                // Convert hex color to integer
                color = parseInt(options.color.substring(1), 16);
            } else if (typeof options.color === 'number') {
                color = options.color;
            }
        }

        // Create the embed
        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title)
            .setDescription(description)
            .setTimestamp()
            .setFooter({ text: '24BOT Ticket System' });

        // Create the category select menu
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('tickets:select')
            .setPlaceholder('Select a ticket category');

        // Add options to the select menu
        // Handle both array of strings and array of objects formats
        if (categories.length > 0) {
            if (typeof categories[0] === 'string') {
                // If categories is an array of strings
                selectMenu.addOptions(categories.map(category => ({
                    label: category,
                    value: category.toLowerCase().replace(/\s+/g, '-'),
                    description: `Create a ${category} ticket`
                })));
            } else if (typeof categories[0] === 'object') {
                // If categories is an array of objects with name and value
                selectMenu.addOptions(categories.map(category => ({
                    label: category.name,
                    value: category.value,
                    description: `Create a ${category.name} ticket`
                })));
            }
        }

        // Add the select menu to an action row
        const row = new ActionRowBuilder().addComponents(selectMenu);

        return {
            embeds: [embed],
            components: [row]
        };
    },

    /**
     * Handle the ticket category select interaction
     * @param {Object} interaction - The select menu interaction
     * @param {Object} client - The Discord client
     * @param {Array} args - Additional arguments from the custom ID
     */
    async handleSelect(interaction, client, args) {
        try {
            // Get the selected category
            const categoryValue = interaction.values[0];

            // Find category name based on the value
            let categoryName = 'Other';
            for (const category of TICKET_CATEGORIES) {
                if (category.toLowerCase().replace(/\s+/g, '-') === categoryValue) {
                    categoryName = category;
                    break;
                }
            }

            // Check if this category should skip the form
            // Check both hardcoded values and client config
            const skipFormCategories = ['purchase-a-license', 'mixing-&-mastering-services'];
            if (skipFormCategories.includes(categoryValue)) {
                // Skip the form and create the ticket directly
                await interaction.deferReply({ ephemeral: true });

                // Create default subject and description
                const subject = `${categoryName} Request`;
                const description = `A new ${categoryName} request`;

                // Create the ticket using our existing ticket creation logic
                await this.createTicket(
                    interaction,
                    client,
                    categoryValue,
                    categoryName,
                    subject,
                    description
                );

                return;
            }

            // For other categories, show the form modal
            const modal = new ModalBuilder()
                .setCustomId(`tickets:modal:${categoryValue}`)
                .setTitle(`New ${categoryName} Ticket`);

            // Add inputs to the modal
            const subjectInput = new TextInputBuilder()
                .setCustomId('ticketSubject')
                .setLabel('Subject')
                .setPlaceholder('Briefly describe your issue or request')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMaxLength(100);

            const descriptionInput = new TextInputBuilder()
                .setCustomId('ticketDescription')
                .setLabel('Description')
                .setPlaceholder('Please provide all necessary details about your issue or request')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
                .setMaxLength(1000);

            // Add inputs to action rows
            const firstRow = new ActionRowBuilder().addComponents(subjectInput);
            const secondRow = new ActionRowBuilder().addComponents(descriptionInput);

            // Add action rows to the modal
            modal.addComponents(firstRow, secondRow);

            // Show the modal
            await interaction.showModal(modal);
        } catch (error) {
            console.error('Error handling ticket select:', error);

            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: 'There was an error creating your ticket.',
                    ephemeral: true
                });
            }
        }
    },

    /**
     * Handle the ticket modal submission
     * @param {Object} interaction - The modal submission interaction
     * @param {Object} client - The Discord client
     * @param {Array} args - Additional arguments from the custom ID
     */
    async handleModal(interaction, client, args) {
        try {
            // Get the category value from the modal customId
            const categoryValue = args[0];

            // Find category name based on the value
            let categoryName = 'Other';

            // Check if it's one of our predefined categories
            for (const category of TICKET_CATEGORIES) {
                if (category.toLowerCase().replace(/\s+/g, '-') === categoryValue) {
                    categoryName = category;
                    break;
                }
            }

            // Get values from the modal inputs
            const subject = interaction.fields.getTextInputValue('ticketSubject');
            const description = interaction.fields.getTextInputValue('ticketDescription');

            // Defer reply to have more time to process
            await interaction.deferReply({ ephemeral: true });

            // Create the ticket using our common ticket creation method
            await this.createTicket(
                interaction,
                client,
                categoryValue,
                categoryName,
                subject,
                description
            );

        } catch (error) {
            console.error('Error creating ticket:', error);

            await interaction.editReply({
                content: `Failed to create ticket: ${error.message}`,
                ephemeral: true
            });
        }
    },

    /**
     * Handle ticket-related button interactions
     * @param {Object} interaction - The button interaction
     * @param {Object} client - The Discord client
     * @param {String} customId - The full custom ID
     * @param {Array} args - Additional arguments from the custom ID
     */
    async handleButton(interaction, client, args) {
        try {
            const action = args[0];

            // Handle different button actions
            switch (action) {
                case 'takeover':
                    await this.handleTakeover(interaction, client, args[1], args[2], args[3] === '1');
                    break;
                case 'close':
                    await this.handleClose(interaction, client, args[1], args[2], args[3] === '1');
                    break;
                case 'confirm-close':
                    await this.handleConfirmClose(interaction, client, args[1], args[2], args[3] === '1');
                    break;
                case 'cancel-close':
                    await interaction.update({
                        content: 'Ticket closure cancelled.',
                        components: []
                    });
                    break;
            }
        } catch (error) {
            console.error('Error handling ticket button:', error);

            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: 'There was an error processing your request.',
                    ephemeral: true
                });
            }
        }
    },

    /**
     * Handle ticket takeover
     */
    async handleTakeover(interaction, client, ticketId, categoryValue, isAdmin) {
        // Check if the user has the admin role
        const adminRoleId = client.config.adminRoleId;
        const hasAdminRole = interaction.member.roles.cache.has(adminRoleId);

        if (!hasAdminRole) {
            return await interaction.reply({
                content: 'You do not have permission to take over this ticket.',
                ephemeral: true
            });
        }

        // Get the channel and update permissions
        const channel = interaction.channel;

        // Hide channel from admin role and give access only to this admin
        await channel.permissionOverwrites.edit(adminRoleId, {
            ViewChannel: false
        });
        
        await channel.permissionOverwrites.edit(interaction.user.id, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true,
            ManageMessages: true
        });

        // Get the ticket creator
        // Find category name based on the value
        let categoryName = 'Other';

        // Check if it's one of our predefined categories
        for (const category of TICKET_CATEGORIES) {
            if (category.toLowerCase().replace(/\s+/g, '-') === categoryValue) {
                categoryName = category;
                break;
            }
        }

        // Mark the admin as having taken over
        // Remove the takeover button and update the close button
        const closeButton = new ButtonBuilder()
            .setCustomId(`tickets:close:${ticketId}:${categoryValue}:1`)
            .setLabel('Close')
            .setStyle(ButtonStyle.Danger);

        const buttonRow = new ActionRowBuilder().addComponents(closeButton);

        // Update the message
        await interaction.update({
            components: [buttonRow]
        });

        // Send a takeover message
        await channel.send({
            content: `Ticket has been taken over by ${interaction.user}`,
            components: []
        });

        // Find the ticket creator (the first user with permissions)
        const ticketCreator = await this.findTicketCreator(channel, client.user.id, adminRoleId);

        // Log the takeover
        if (ticketCreator) {
            await logger.logTicket(client, {
                type: 'takeover',
                user: ticketCreator,
                admin: interaction.user,
                ticketId: parseInt(ticketId),
                category: categoryName
            });
        }
    },

    /**
     * Handle ticket close request
     */
    async handleClose(interaction, client, ticketId, categoryValue, isAdmin) {
        // If user is not admin, check if they are the ticket creator
        const adminRoleId = client.config.adminRoleId;
        const hasAdminRole = interaction.member.roles.cache.has(adminRoleId);
        const isCreator = await this.isTicketCreator(interaction.channel, interaction.user.id);

        if (!hasAdminRole && !isCreator) {
            return await interaction.reply({
                content: 'You do not have permission to close this ticket.',
                ephemeral: true
            });
        }

        // Ask for confirmation
        const confirmButton = new ButtonBuilder()
            .setCustomId(`tickets:confirm-close:${ticketId}:${categoryValue}:${isAdmin ? '1' : '0'}`)
            .setLabel('Confirm Close')
            .setStyle(ButtonStyle.Danger);

        const cancelButton = new ButtonBuilder()
            .setCustomId(`tickets:cancel-close`)
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary);

        const buttonRow = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

        await interaction.reply({
            content: 'Are you sure you want to close this ticket? This cannot be undone.',
            components: [buttonRow],
            ephemeral: true
        });
    },

    // Generate transcript from channel messages
    async generateTranscript(channel) {
        const messages = await channel.messages.fetch({ limit: 100 });
        let transcript = `Ticket Transcript\n==================\n\n`;

        messages.reverse().forEach(msg => {
            const timestamp = msg.createdAt.toLocaleString();
            // Replace mentions with usernames
            let content = msg.content;
            msg.mentions.users.forEach(user => {
                content = content.replace(`<@${user.id}>`, user.username);
                content = content.replace(`<@!${user.id}>`, user.username);
            });
            transcript += `[${timestamp}] ${msg.author.username}: ${content}\n`;

            // Add attachments if any
            msg.attachments.forEach(attachment => {
                transcript += `[Attachment: ${attachment.url}]\n`;
            });
            transcript += '\n';
        });

        return transcript;
    },

    /**
     * Handle ticket confirm close
     */
    async handleConfirmClose(interaction, client, ticketId, categoryValue, isAdmin) {
        // Update the reply
        await interaction.update({
            content: 'Closing ticket...',
            components: []
        });

        const channel = interaction.channel;

        // Generate transcript before closing
        const transcript = await this.generateTranscript(channel);
        const transcriptBuffer = Buffer.from(transcript, 'utf-8');

        // Create transcript attachment
        const transcriptAttachment = {
            attachment: transcriptBuffer,
            name: `ticket-${ticketId}-transcript.txt`
        };

        // Find the ticket creator before deleting
        const adminRoleId = client.config.adminRoleId;
        const ticketCreator = await this.findTicketCreator(channel, client.user.id, adminRoleId);

        // Send transcript to log channel
        const logChannel = await interaction.guild.channels.fetch(client.config.logChannelId);
        if (logChannel) {
            await logChannel.send({
                content: `Ticket #${ticketId} closed by ${interaction.user.tag}`,
                files: [transcriptAttachment]
            });
        }

        // Find category name based on the value
        let categoryName = 'Other';

        // Check if it's one of our predefined categories
        for (const category of TICKET_CATEGORIES) {
            if (category.toLowerCase().replace(/\s+/g, '-') === categoryValue) {
                categoryName = category;
                break;
            }
        }


        // Log the ticket deletion (using 'delete' type for the specified format)
        if (ticketCreator) {
            await logger.logTicket(client, {
                type: 'delete', // Use 'delete' type to match the requested format
                user: ticketCreator,
                admin: interaction.user,
                ticketId: parseInt(ticketId),
                category: categoryName,
                transcriptAttachment
            });
        }

        // Send a closing message
        await channel.send({
            content: `Ticket has been closed by ${interaction.user}`,
            components: []
        });

        // Wait a bit before deleting to allow users to see the message
        setTimeout(async () => {
            try {
                await channel.delete(`Ticket #${ticketId} closed by ${interaction.user.tag}`);
            } catch (error) {
                console.error(`Error deleting ticket channel: ${error}`);
            }
        }, 5000);
    },

    // Helper function to find the ticket creator
    async findTicketCreator(channel, botId, adminRoleId) {
        try {
            const permissionOverwrites = channel.permissionOverwrites.cache;

            for (const [id, overwrite] of permissionOverwrites) {
                // Skip the @everyone role, the bot, and the admin role
                if (id === channel.guild.id || id === botId || id === adminRoleId) continue;

                // If this is a user with view channel permission, they're probably the creator
                if (overwrite.type === 1 && overwrite.allow.has(PermissionFlagsBits.ViewChannel)) {
                    return await channel.guild.members.fetch(id).catch(() => null);
                }
            }

            return null;
        } catch (error) {
            console.error('Error finding ticket creator:', error);
            return null;
        }
    },

    // Helper function to check if a user is the ticket creator
    async isTicketCreator(channel, userId) {
        try {
            const permissionOverwrites = channel.permissionOverwrites.cache;
            const userOverwrite = permissionOverwrites.get(userId);

            // If user has explicit permissions and can view the channel, they might be the creator
            return userOverwrite && 
                   userOverwrite.type === 1 && 
                   userOverwrite.allow.has(PermissionFlagsBits.ViewChannel);
        } catch (error) {
            console.error('Error checking if user is ticket creator:', error);
            return false;
        }
    },

    /**
     * Create a new ticket with the provided details
     * Used by both the modal handler and the direct creation path
     */
    async createTicket(interaction, client, categoryValue, categoryName, subject, description) {
        try {
            // Create a new ticket channel
            const ticketId = ticketCounter++;
            const channelName = `┇ᴛɪᴄᴋᴇᴛ-${ticketId}`;

            // Create the channel with permissions
            const adminRoleId = client.config.adminRoleId;

            // Check if a specific category ID is set in config
            const ticketCategoryId = '1177251094380949577';

            // Create channel options
            const channelOptions = {
                name: channelName,
                type: ChannelType.GuildText,
            };

            // Add parent category if it exists
            if (ticketCategoryId) {
                channelOptions.parent = ticketCategoryId;
            }

            const channel = await interaction.guild.channels.create({
                ...channelOptions,
                permissionOverwrites: [
                    // Default permissions (can't see the channel)
                    {
                        id: interaction.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    // Ticket creator can see and write in the channel
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AddReactions
                        ]
                    },
                    // Admin role can see and interact with the channel
                    {
                        id: client.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.ManageChannels
                        ]
                    }
                ]
            });

            // Add admin role permissions if it exists
            if (adminRoleId) {
                await channel.permissionOverwrites.edit(adminRoleId, {
                    ViewChannel: true,
                    SendMessages: true,
                    ReadMessageHistory: true,
                    ManageMessages: true,
                    AddReactions: true
                });
            }

            // Create the initial ticket message
            // Get color from client config or use default
            let embedColor = 0x808080; // Default to gray
            if (client.config.ticketPanel && client.config.ticketPanel.color) {
                const configColor = client.config.ticketPanel.color;
                if (typeof configColor === 'string' && configColor.startsWith('#')) {
                    embedColor = parseInt(configColor.substring(1), 16);
                } else if (typeof configColor === 'number') {
                    embedColor = configColor;
                }
            }

            const ticketEmbed = new EmbedBuilder()
                .setColor(embedColor)
                .setTitle(`Ticket #${ticketId}: ${subject}`)
                .setDescription(`**Category:** ${categoryName}\n\n${description}`)
                .setTimestamp()
                .setFooter({ text: `Opened by ${interaction.user.tag}` });

            // Create the control buttons
            const takeoverButton = new ButtonBuilder()
                .setCustomId(`tickets:takeover:${ticketId}:${categoryValue}:0`)
                .setLabel('Take Over')
                .setStyle(ButtonStyle.Primary);

            const closeButton = new ButtonBuilder()
                .setCustomId(`tickets:close:${ticketId}:${categoryValue}:0`)
                .setLabel('Close')
                .setStyle(ButtonStyle.Danger);

            const buttonRow = new ActionRowBuilder().addComponents(takeoverButton, closeButton);

            // Check for custom ticket message
            let messageContent = `<@${interaction.user.id}> created a ticket. <@&${adminRoleId || interaction.guild.id}>`;

            // If there's a custom message for this category, use it
            if (client.config.ticketMessages && client.config.ticketMessages[categoryValue]) {
                // Replace placeholders in the custom message
                let customMessage = client.config.ticketMessages[categoryValue];
                customMessage = customMessage.replace(/{user}/g, `<@${interaction.user.id}>`);
                customMessage = customMessage.replace(/{admin}/g, `<@&${adminRoleId || interaction.guild.id}>`);
                customMessage = customMessage.replace(/{ticket-id}/g, ticketId);
                customMessage = customMessage.replace(/{category}/g, categoryName);

                // Handle countdown text placeholder if exists
                if (customMessage.includes('{countdown-text}')) {
                    if (client.config.countdownFormat) {
                        if (typeof client.config.countdownFormat === 'object' && client.config.countdownFormat.text) {
                            customMessage = customMessage.replace(/{countdown-text}/g, client.config.countdownFormat.text);
                        } else if (typeof client.config.countdownFormat === 'string') {
                            // Support legacy format
                            customMessage = customMessage.replace(/{countdown-text}/g, client.config.countdownFormat);
                        } else {
                            customMessage = customMessage.replace(/{countdown-text}/g, 'Countdown not set');
                        }
                    } else {
                        customMessage = customMessage.replace(/{countdown-text}/g, 'Countdown not set');
                    }
                }

                messageContent = customMessage;
            }

            // Send the initial ticket message
            await channel.send({
                content: messageContent,
                embeds: [ticketEmbed],
                components: [buttonRow]
            });

            // Log the ticket creation
            await logger.logTicket(client, {
                type: 'create',
                user: interaction.user,
                ticketId: ticketId,
                category: categoryName,
                channel: channel
            });

            // Reply to the interaction
            await interaction.editReply({
                content: `Ticket created ${channel}`,
                ephemeral: true
            });

            return channel;
        } catch (error) {
            console.error('Error creating ticket:', error);

            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: `Failed to create ticket: ${error.message}`,
                    ephemeral: true
                });
            } else {
                await interaction.editReply({
                    content: `Failed to create ticket: ${error.message}`,
                    ephemeral: true
                });
            }

            return null;
        }
    }
};