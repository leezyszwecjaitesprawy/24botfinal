const logger = require('../utils/logger');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        try {
            // Log the member leave in console
            console.log(`Member left: ${member.user.tag}`);
            
            // Update the member count channel
            await logger.updateMemberCount(client, member.guild);
            
            // Check if the user was kicked or banned
            // We don't want to show "user left" message for kicks or bans
            // Fetch the audit logs
            const fetchedLogs = await member.guild.fetchAuditLogs({
                limit: 1,
                type: AuditLogEvent.MemberKick,
            });
            
            // Find the first relevant log entry
            const kickLog = fetchedLogs.entries.first();
            
            // Check if there was a kick log in the last 5 seconds for this user
            const recentKick = kickLog && 
                               kickLog.target.id === member.id && 
                               kickLog.createdTimestamp > (Date.now() - 5000);
            
            // Only send "user left" message if they weren't kicked
            if (!recentKick) {
                // Also check for bans
                const banLogs = await member.guild.fetchAuditLogs({
                    limit: 1,
                    type: AuditLogEvent.MemberBanAdd,
                });
                
                const banLog = banLogs.entries.first();
                const recentBan = banLog && 
                                  banLog.target.id === member.id && 
                                  banLog.createdTimestamp > (Date.now() - 5000);
                
                // If they weren't banned either, log the leave message
                if (!recentBan) {
                    await logger.logModeration(client, {
                        type: 'leave',
                        user: member.user,
                        guild: member.guild
                    });
                }
            }
        } catch (error) {
            console.error('Error in guildMemberRemove event:', error);
        }
    }
};