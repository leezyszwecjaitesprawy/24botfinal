module.exports = {
    name: 'voiceStateUpdate',
    async execute(oldState, newState, client) {
        try {
            // Check if the create channel ID is set
            const createChannelId = client.config.createChannelId;
            if (!createChannelId) return;
            
            // Get the voice channel format from config
            const voiceChannelFormat = client.config.voiceChannelFormat || '┇ {username}';
            
            // Get the user
            const user = newState.member;
            if (!user) return;
            
            // User joined the "create channel" voice channel
            if (newState.channelId === createChannelId && (!oldState.channelId || oldState.channelId !== createChannelId)) {
                // Get the category of the create channel
                const createChannel = newState.channel;
                if (!createChannel) return;
                
                const categoryId = createChannel.parentId;
                
                // Create a new voice channel with the user's name
                const channelName = voiceChannelFormat.replace('{username}', user.displayName);
                
                try {
                    // Create the new channel in the same category
                    const newChannel = await newState.guild.channels.create({
                        name: channelName,
                        type: 2, // Voice channel
                        parent: categoryId,
                        permissionOverwrites: [
                            {
                                id: user.id,
                                allow: ['ManageChannels', 'MuteMembers', 'DeafenMembers', 'MoveMembers'],
                            },
                        ],
                    });
                    
                    // Move the user to the new channel
                    await user.voice.setChannel(newChannel.id);
                    console.log(`Created voice channel for ${user.user.tag}: ${channelName}`);
                } catch (error) {
                    console.error(`Failed to create voice channel for ${user.user.tag}:`, error);
                }
            }
            
            // Check for empty voice channels after a user leaves
            if (oldState.channelId && oldState.channelId !== createChannelId) {
                const oldChannel = oldState.channel;
                
                // If the channel still exists and is now empty, delete it
                // Exception: Don't delete the create channel or channels that aren't in the same category
                if (oldChannel && 
                    oldChannel.id !== createChannelId && 
                    oldChannel.members.size === 0 &&
                    oldChannel.parentId === (newState.guild.channels.cache.get(createChannelId)?.parentId)) {
                    
                    try {
                        // Check if the channel name matches our format (to avoid deleting permanent channels)
                        if (oldChannel.name.startsWith('┇')) {
                            await oldChannel.delete();
                            console.log(`Deleted empty voice channel: ${oldChannel.name}`);
                        }
                    } catch (error) {
                        console.error(`Failed to delete empty voice channel: ${oldChannel.name}`, error);
                    }
                }
            }
        } catch (error) {
            console.error('Error in voiceStateUpdate event:', error);
        }
    }
};