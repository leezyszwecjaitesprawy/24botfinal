const { InteractionType, EmbedBuilder } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        try {
            // Handle different interaction types
            if (interaction.isChatInputCommand()) {
                await handleChatInputCommand(interaction, client);
            } else if (interaction.isButton()) {
                await handleButtonInteraction(interaction, client);
            } else if (interaction.isStringSelectMenu()) {
                await handleSelectMenuInteraction(interaction, client);
            } else if (interaction.isModalSubmit()) {
                await handleModalSubmitInteraction(interaction, client);
            }
        } catch (error) {
            console.error('Error in interactionCreate event:', error);
            
            // Try to respond to the interaction if it hasn't been responded to already
            if (interaction.deferred || interaction.replied) return;
            
            const errorResponse = { 
                content: 'Wystąpił błąd podczas przetwarzania tej interakcji.', 
                ephemeral: true 
            };
            
            try {
                if (interaction.isRepliable()) {
                    await interaction.reply(errorResponse);
                }
            } catch (replyError) {
                console.error('Failed to reply with error message:', replyError);
            }
        }
    }
};

// Handle slash commands
async function handleChatInputCommand(interaction, client) {
    const command = client.commands.get(interaction.commandName);
    
    // If the command doesn't exist, return
    if (!command) {
        console.error(`No command matching ${interaction.commandName} was found.`);
        return;
    }
    
    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(`Error executing ${interaction.commandName} command:`, error);
        
        // Reply with error message if the interaction hasn't been replied to yet
        if (interaction.deferred || interaction.replied) return;
        
        await interaction.reply({ 
            content: 'Wystąpił błąd podczas wykonywania tego polecenia.', 
            ephemeral: true 
        });
    }
}

// Handle button interactions
async function handleButtonInteraction(interaction, client) {
    const customId = interaction.customId;
    
    // Split customId on : to get component and arguments
    // Format: componentName:arg1:arg2:...
    const [componentName, ...args] = customId.split(':');
    
    // Load all component files
    const componentsPath = path.join(__dirname, '..', 'components');
    if (fs.existsSync(componentsPath)) {
        const componentFiles = fs.readdirSync(componentsPath).filter(file => file.endsWith('.js'));
        
        // Find the component that handles this button
        for (const file of componentFiles) {
            const filePath = path.join(componentsPath, file);
            const component = require(filePath);
            
            // Check if the component has a handleButton method
            if (component.handleButton && componentName === path.parse(file).name) {
                await component.handleButton(interaction, client, args);
                return;
            }
        }
    }
    
    // If no component handled this button
    console.warn(`No component handled button with customId: ${customId}`);
}

// Handle select menu interactions
async function handleSelectMenuInteraction(interaction, client) {
    const customId = interaction.customId;
    
    // Split customId on : to get component and arguments
    // Format: componentName:arg1:arg2:...
    const [componentName, ...args] = customId.split(':');
    
    // Load all component files
    const componentsPath = path.join(__dirname, '..', 'components');
    if (fs.existsSync(componentsPath)) {
        const componentFiles = fs.readdirSync(componentsPath).filter(file => file.endsWith('.js'));
        
        // Find the component that handles this select menu
        for (const file of componentFiles) {
            const filePath = path.join(componentsPath, file);
            const component = require(filePath);
            
            // Check if the component has a handleSelect method
            if (component.handleSelect && componentName === path.parse(file).name) {
                await component.handleSelect(interaction, client, args);
                return;
            }
        }
    }
    
    // If no component handled this select menu
    console.warn(`No component handled select menu with customId: ${customId}`);
}

// Handle modal submit interactions
async function handleModalSubmitInteraction(interaction, client) {
    const customId = interaction.customId;
    
    // Handle special cases for say and ticket message commands
    if (customId.startsWith('say:')) {
        await handleSayModal(interaction, client, customId);
        return;
    } else if (customId.startsWith('ticketmessage:')) {
        await handleTicketMessageModal(interaction, client, customId);
        return;
    } else if (customId.startsWith('ticketpanel:')) {
        await handleTicketPanelModal(interaction, client, customId);
        return;
    }
    
    // Split customId on : to get component and arguments
    // Format: componentName:arg1:arg2:...
    const [componentName, ...args] = customId.split(':');
    
    // Load all component files
    const componentsPath = path.join(__dirname, '..', 'components');
    if (fs.existsSync(componentsPath)) {
        const componentFiles = fs.readdirSync(componentsPath).filter(file => file.endsWith('.js'));
        
        // Find the component that handles this modal
        for (const file of componentFiles) {
            const filePath = path.join(componentsPath, file);
            const component = require(filePath);
            
            // Check if the component has a handleModal method
            if (component.handleModal && componentName === path.parse(file).name) {
                await component.handleModal(interaction, client, args);
                return;
            }
        }
    }
    
    // If no component handled this modal
    console.warn(`No component handled modal with customId: ${customId}`);
}

// Handle modal submission for the /say command
async function handleSayModal(interaction, client, customId) {
    // Extract the channel ID from the customId
    const channelId = customId.split(':')[1];
    
    // Get the message content from the modal
    const messageContent = interaction.fields.getTextInputValue('message_content');
    
    // Find the target channel
    const channel = interaction.guild.channels.cache.get(channelId);
    
    if (!channel) {
        return await interaction.reply({
            content: 'Could not find the target channel. The channel may have been deleted.',
            ephemeral: true
        });
    }
    
    try {
        // Check if the bot has permission to send messages in the target channel
        if (!channel.permissionsFor(interaction.client.user).has('SendMessages')) {
            return await interaction.reply({
                content: `I don't have permission to send messages in ${channel}.`,
                ephemeral: true
            });
        }
        
        // Send the message
        await channel.send(messageContent);
        
        // Prepare a preview of the message for the confirmation
        let messagePreview = messageContent;
        const previewMaxLength = 200;
        if (messageContent.length > previewMaxLength) {
            // Find the nearest line break before the max length
            let cutoffIndex = messageContent.substring(0, previewMaxLength).lastIndexOf('\n');
            if (cutoffIndex === -1 || cutoffIndex < previewMaxLength / 2) {
                cutoffIndex = previewMaxLength - 3; // Default cutoff if no suitable line break
            }
            messagePreview = messageContent.substring(0, cutoffIndex) + '...';
        }
        
        // Reply to the interaction with a confirmation
        await interaction.reply({
            content: `Advanced message sent to ${channel}.\n\n**Preview:**\n${messagePreview}`,
            ephemeral: true
        });
    } catch (error) {
        console.error('Error in say command (modal):', error);
        
        await interaction.reply({
            content: `Failed to send the message: ${error.message}`,
            ephemeral: true
        });
    }
}

// Handle modal submission for the ticket message command
async function handleTicketMessageModal(interaction, client, customId) {
    try {
        // Extract the category from the customId
        const category = customId.split(':')[1];
        
        // Get the message content from the modal
        const messageContent = interaction.fields.getTextInputValue('ticketMessageContent');
        
        // Get all ticket categories to find the display name
        const TICKET_CATEGORIES = [
            { name: 'Proposition', value: 'proposition' },
            { name: 'Support', value: 'support' },
            { name: 'Mixing & Mastering services', value: 'mixing-mastering-services' },
            { name: 'Purchase a license', value: 'purchase-a-license' },
            { name: 'Other', value: 'other' }
        ];
        
        // Get category name for display
        const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
        
        // Initialize ticketMessages object if it doesn't exist
        if (!client.config.ticketMessages) {
            client.config.ticketMessages = {};
        }
        
        // Save the message for this category
        client.config.ticketMessages[category] = messageContent;
        
        // Create a preview for the confirmation message
        let messagePreview = messageContent;
        const previewMaxLength = 200;
        if (messageContent.length > previewMaxLength) {
            let cutoffIndex = messageContent.substring(0, previewMaxLength).lastIndexOf('\n');
            if (cutoffIndex === -1 || cutoffIndex < previewMaxLength / 2) {
                cutoffIndex = previewMaxLength - 3;
            }
            messagePreview = messageContent.substring(0, cutoffIndex) + '...';
        }
        
        // Show a preview of how placeholders would be rendered
        let examplePreview = messageContent
            .replace(/{user}/g, '@user')
            .replace(/{admin}/g, '@admin')
            .replace(/{ticket-id}/g, '123')
            .replace(/{category}/g, categoryName);
            
        // Handle countdown text placeholder if exists
        if (examplePreview.includes('{countdown-text}')) {
            if (client.config.countdownFormat) {
                if (typeof client.config.countdownFormat === 'object' && client.config.countdownFormat.text) {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, client.config.countdownFormat.text);
                } else if (typeof client.config.countdownFormat === 'string') {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, client.config.countdownFormat);
                } else {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, 'Countdown not set');
                }
            } else {
                examplePreview = examplePreview.replace(/{countdown-text}/g, 'Countdown not set');
            }
        }
        
        // Create an embed to display the preview
        const previewEmbed = new EmbedBuilder()
            .setTitle(`Message for ${categoryName} Tickets`)
            .setDescription(examplePreview)
            .setColor('#0099ff')
            .setFooter({ text: 'Preview with placeholder substitution' });
            
        // Reply to the interaction with a confirmation and preview
        await interaction.reply({
            content: `Custom message set for ${categoryName} tickets.`,
            embeds: [previewEmbed],
            ephemeral: true
        });
        
        // If this was from the editor view with buttons, refresh the view after a short delay
        if (interaction.message && interaction.message.components.some(row => 
            row.components.some(component => component.customId?.startsWith('ticketmessage_editor'))
        )) {
            setTimeout(async () => {
                try {
                    // Find the command module
                    const ticketMessageCommand = interaction.client.commands.get('setup-ticketmessage');
                    if (ticketMessageCommand && ticketMessageCommand.handleViewMessages) {
                        await ticketMessageCommand.handleViewMessages(interaction);
                    }
                } catch (error) {
                    console.error('Error refreshing ticket message view:', error);
                }
            }, 1500);
        }
    } catch (error) {
        console.error('Error in ticket message modal:', error);
        
        await interaction.reply({
            content: `Failed to set ticket message: ${error.message}`,
            ephemeral: true
        });
    }
}

// Handle modal submission for the ticket panel editor
async function handleTicketPanelModal(interaction, client, customId) {
    try {
        // Extract the field type from the customId
        const field = customId.split(':')[1];
        
        // Initialize the panel settings if they don't exist
        if (!client.config.ticketPanel) {
            client.config.ticketPanel = {
                title: 'Support Tickets',
                description: '**Wybierz kategorię zgłoszenia, a następnie wypełnij formularz.**\n\nPo utworzeniu zgłoszenia, Admin <@&1141712746417762359> się z Tobą skontaktuje oraz zapozna się z twoim problemem. Prosimy o cierpliwość i oczekiwanie na odpowiedź.',
                categories: [
                    { name: 'Proposition', value: 'proposition' },
                    { name: 'Support', value: 'support' },
                    { name: 'Mixing & Mastering services', value: 'mixing-mastering-services' },
                    { name: 'Purchase a license', value: 'purchase-a-license' },
                    { name: 'Other', value: 'other' }
                ]
            };
        }
        
        if (field === 'title') {
            // Get the title from the modal
            const title = interaction.fields.getTextInputValue('ticketPanelTitle');
            
            // Save the title
            client.config.ticketPanel.title = title;
            
            // Reply with confirmation
            await interaction.reply({
                content: `Ticket panel title updated to: **${title}**`,
                ephemeral: true
            });
            
            // Preview the updated panel after a short delay
            setTimeout(async () => {
                try {
                    // Find the command module
                    const ticketPanelCommand = interaction.client.commands.get('setup-ticketpanel');
                    if (ticketPanelCommand && ticketPanelCommand.handlePreviewPanel) {
                        await ticketPanelCommand.handlePreviewPanel(interaction);
                    }
                } catch (error) {
                    console.error('Error showing ticket panel preview:', error);
                }
            }, 1500);
        } else if (field === 'description') {
            // Get the description from the modal
            const description = interaction.fields.getTextInputValue('ticketPanelDescription');
            
            // Save the description
            client.config.ticketPanel.description = description;
            
            // Create a preview for the confirmation
            let descriptionPreview = description;
            const previewMaxLength = 200;
            if (description.length > previewMaxLength) {
                let cutoffIndex = description.substring(0, previewMaxLength).lastIndexOf('\n');
                if (cutoffIndex === -1 || cutoffIndex < previewMaxLength / 2) {
                    cutoffIndex = previewMaxLength - 3;
                }
                descriptionPreview = description.substring(0, cutoffIndex) + '...';
            }
            
            // Reply with confirmation
            await interaction.reply({
                content: `Ticket panel description updated!\n\n**Preview:**\n${descriptionPreview}`,
                ephemeral: true
            });
            
            // Preview the updated panel after a short delay
            setTimeout(async () => {
                try {
                    // Find the command module
                    const ticketPanelCommand = interaction.client.commands.get('setup-ticketpanel');
                    if (ticketPanelCommand && ticketPanelCommand.handlePreviewPanel) {
                        await ticketPanelCommand.handlePreviewPanel(interaction);
                    }
                } catch (error) {
                    console.error('Error showing ticket panel preview:', error);
                }
            }, 1500);
        } else {
            await interaction.reply({
                content: `Unknown field: ${field}`,
                ephemeral: true
            });
        }
    } catch (error) {
        console.error('Error in ticket panel modal:', error);
        
        await interaction.reply({
            content: `Failed to update ticket panel: ${error.message}`,
            ephemeral: true
        });
    }
}