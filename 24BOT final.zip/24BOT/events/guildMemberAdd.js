const logger = require('../utils/logger');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        try {
            // Log the new member join in console
            console.log(`New member joined: ${member.user.tag}`);
            
            // Update the member count channel
            await logger.updateMemberCount(client, member.guild);
            
            // You can add a welcome message here if needed
            // const welcomeChannel = member.guild.channels.cache.get('welcome-channel-id');
            // if (welcomeChannel) {
            //    welcomeChannel.send(`Welcome to the server, ${member}!`);
            // }
            
        } catch (error) {
            console.error('Error in guildMemberAdd event:', error);
        }
    }
};