const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        try {
            console.log(`Logged in as ${client.user.tag}!`);
            
            // Set bot activity (status)
            client.user.setPresence({
                activities: [{ name: '24LIFE', type: ActivityType.Listening }],
                status: 'online',
            });
            
            console.log(`Bot activity set to: Listening to 24LIFE`);
            
            // Initialize all components
            this.initializeComponents(client);
            
            // Set up bot configuration from environment variables
            this.setupConfig(client);
            
            console.log('Bot is ready and fully initialized!');
        } catch (error) {
            console.error('Error in ready event:', error);
        }
    },
    
    // Initialize component modules
    initializeComponents(client) {
        try {
            // Load components (these handle interactions like buttons, selects, etc.)
            const fs = require('node:fs');
            const path = require('node:path');
            
            const componentsPath = path.join(__dirname, '..', 'components');
            if (fs.existsSync(componentsPath)) {
                const componentFiles = fs.readdirSync(componentsPath).filter(file => file.endsWith('.js'));
                
                for (const file of componentFiles) {
                    const filePath = path.join(componentsPath, file);
                    const component = require(filePath);
                    
                    if (component.init) {
                        component.init(client);
                        console.log(`Initialized component: ${file}`);
                    }
                }
            }
        } catch (error) {
            console.error('Error initializing components:', error);
        }
    },
    
    // Setup configuration
    setupConfig(client) {
        try {
            // Initialize config if it doesn't exist
            if (!client.config) {
                client.config = {};
            }
            
            // Default values
            const defaultConfig = {
                adminRoleId: '1141712746417762359', // Default admin role ID
                logChannelId: '1354506943238242457', // Default log channel ID
                memberCountChannelId: '1303022009277485066', // Default member count channel ID
                createChannelId: '1141736210411302936', // Default voice creation channel ID
                voiceChannelFormat: '┇ {username}', // Default voice channel name format
                memberCountFormat: '👥│{count} MEMBERS', // Default member count channel name format
                countdownFormat: {
                    format: '⏱️ {time}',
                    text: null
                } // Default countdown format as object structure
            };
            
            // Environment variables take precedence over defaults
            client.config = {
                adminRoleId: process.env.ADMIN_ROLE_ID || client.config.adminRoleId || defaultConfig.adminRoleId,
                logChannelId: process.env.LOG_CHANNEL_ID || client.config.logChannelId || defaultConfig.logChannelId,
                memberCountChannelId: process.env.MEMBER_COUNT_CHANNEL_ID || client.config.memberCountChannelId || defaultConfig.memberCountChannelId,
                createChannelId: process.env.CREATE_CHANNEL_ID || client.config.createChannelId || defaultConfig.createChannelId,
                voiceChannelFormat: process.env.VOICE_CHANNEL_FORMAT || client.config.voiceChannelFormat || defaultConfig.voiceChannelFormat,
                memberCountFormat: process.env.MEMBER_COUNT_FORMAT || client.config.memberCountFormat || defaultConfig.memberCountFormat
            };
            
            // Handle countdown format specially to support both string and object formats
            if (process.env.COUNTDOWN_FORMAT) {
                client.config.countdownFormat = {
                    format: process.env.COUNTDOWN_FORMAT,
                    text: null
                };
            } else if (client.config.countdownFormat) {
                // If it's already in client.config, preserve it (could be string or object)
                if (typeof client.config.countdownFormat === 'string') {
                    // Convert from string to object
                    client.config.countdownFormat = {
                        format: client.config.countdownFormat,
                        text: null
                    };
                }
                // If it's already an object, keep it as is
            } else {
                // Use the default
                client.config.countdownFormat = defaultConfig.countdownFormat;
            }
            
            console.log('Configuration loaded with the following values:');
            console.log(`- Admin Role ID: ${client.config.adminRoleId}`);
            console.log(`- Log Channel ID: ${client.config.logChannelId}`);
            console.log(`- Member Count Channel ID: ${client.config.memberCountChannelId}`);
            console.log(`- Voice Create Channel ID: ${client.config.createChannelId}`);
            console.log(`- Member Count Format: ${client.config.memberCountFormat}`);
            // Special handling for countdown format logging since it's now an object
            if (typeof client.config.countdownFormat === 'object') {
                console.log(`- Countdown Format: ${client.config.countdownFormat.format}`);
                if (client.config.countdownFormat.text) {
                    console.log(`- Countdown Text: ${client.config.countdownFormat.text}`);
                }
            } else {
                console.log(`- Countdown Format: ${client.config.countdownFormat}`);
            }
        } catch (error) {
            console.error('Error setting up configuration:', error);
        }
    }
};