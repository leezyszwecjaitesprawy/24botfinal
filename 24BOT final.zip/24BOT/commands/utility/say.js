const { 
    SlashCommandBuilder, 
    PermissionFlagsBits, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder 
} = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('say')
        .setDescription('Makes the bot say something')
        .addStringOption(option =>
            option.setName('message')
                .setDescription('The message to send (use \\n for line breaks or use /say-advanced)')
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to send the message to (defaults to current channel)'))
        .addBooleanOption(option => 
            option.setName('advanced')
                .setDescription('Use advanced editor with multiline support'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Check if advanced mode is requested
        const useAdvancedMode = interaction.options.getBoolean('advanced');
        
        if (useAdvancedMode) {
            // Get the channel for storing in the modal custom ID
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            const initialMessage = interaction.options.getString('message');
            
            // Create a modal for multiline input
            const modal = new ModalBuilder()
                .setCustomId(`say:${channel.id}`)
                .setTitle('Advanced Message Editor');
                
            // Create the text input component
            const messageInput = new TextInputBuilder()
                .setCustomId('message_content')
                .setLabel('Message Content')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Enter your multiline message here...')
                .setValue(initialMessage)
                .setRequired(true)
                .setMaxLength(2000);
                
            // Add the text input to an action row
            const actionRow = new ActionRowBuilder().addComponents(messageInput);
            
            // Add the action row to the modal
            modal.addComponents(actionRow);
            
            // Show the modal
            await interaction.showModal(modal);
            return;
        }
        
        // Regular mode - get the message content
        const message = interaction.options.getString('message');
        
        // Get the specified channel or use the current channel
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        
        // Defer the reply
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Check if the bot has permission to send messages in the target channel
            if (!channel.permissionsFor(interaction.client.user).has('SendMessages')) {
                return await interaction.editReply({
                    content: `I don't have permission to send messages in ${channel}.`,
                    ephemeral: true
                });
            }
            
            // Send the message
            await channel.send(message);
            
            // Prepare a preview of the message for the confirmation
            let messagePreview = message;
            if (message.length > 100) {
                messagePreview = message.substring(0, 97) + '...';
            }
            
            // Reply to the interaction with a confirmation and tips
            await interaction.editReply({
                content: `Message sent to ${channel}.\n\n**Preview:**\n${messagePreview}\n\n**Tips:** 
- Use \`\\n\` to create line breaks in your message
- Use \`/say advanced:true\` for a multiline editor`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error in say command:', error);
            
            await interaction.editReply({
                content: `Failed to send the message: ${error.message}`,
                ephemeral: true
            });
        }
    }
};