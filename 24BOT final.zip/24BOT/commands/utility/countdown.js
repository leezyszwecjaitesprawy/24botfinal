const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('countdown')
        .setDescription('Starts a countdown in the channel')
        .addSubcommand(subcommand =>
            subcommand
                .setName('seconds')
                .setDescription('Countdown in seconds')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of seconds for the countdown (1-60)')
                        .setMinValue(1)
                        .setMaxValue(60)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Message to display after the countdown')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('during_message')
                        .setDescription('Message to display during the countdown (will be followed by time left)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('minutes')
                .setDescription('Countdown in minutes')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of minutes for the countdown (1-60)')
                        .setMinValue(1)
                        .setMaxValue(60)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Message to display after the countdown')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('during_message')
                        .setDescription('Message to display during the countdown (will be followed by time left)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('hours')
                .setDescription('Countdown in hours')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of hours for the countdown (1-24)')
                        .setMinValue(1)
                        .setMaxValue(24)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Message to display after the countdown')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('during_message')
                        .setDescription('Message to display during the countdown (will be followed by time left)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('days')
                .setDescription('Countdown in days')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Number of days for the countdown (1-7)')
                        .setMinValue(1)
                        .setMaxValue(7)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Message to display after the countdown')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('during_message')
                        .setDescription('Message to display during the countdown (will be followed by time left)')
                        .setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    
    async execute(interaction) {
        // Get the subcommand and options
        const subcommand = interaction.options.getSubcommand();
        const amount = interaction.options.getInteger('amount');
        const message = interaction.options.getString('message') || 'Countdown finished!';
        const duringMessage = interaction.options.getString('during_message');
        
        // Get custom format from config if available
        let countdownFormat = '⏱️ {time}';
        // Also store the text for the {countdown-text} placeholder for other commands
        let countdownText = null;
        
        if (interaction.client.config && interaction.client.config.countdownFormat) {
            // Check if it's the new object format or old string format
            if (typeof interaction.client.config.countdownFormat === 'string') {
                countdownFormat = interaction.client.config.countdownFormat;
            } else {
                // Use the new object structure
                countdownFormat = interaction.client.config.countdownFormat.format || '⏱️ {time}';
                countdownText = interaction.client.config.countdownFormat.text;
            }
        } else {
            // Fallback to file-based config
            try {
                const configPath = path.join(__dirname, '../../config.json');
                if (fs.existsSync(configPath)) {
                    const configData = fs.readFileSync(configPath, 'utf8');
                    const config = JSON.parse(configData);
                    if (config.countdownFormat) {
                        if (typeof config.countdownFormat === 'string') {
                            countdownFormat = config.countdownFormat;
                        } else {
                            countdownFormat = config.countdownFormat.format || '⏱️ {time}';
                            countdownText = config.countdownFormat.text;
                        }
                    }
                }
            } catch (error) {
                console.error('Error loading countdown format from config file:', error);
            }
        }
        
        // Update the client's config with the current format and text
        if (interaction.client.config) {
            if (!interaction.client.config.countdownFormat || typeof interaction.client.config.countdownFormat === 'string') {
                interaction.client.config.countdownFormat = {
                    format: countdownFormat,
                    text: countdownText
                };
            }
        }
        
        // Calculate total seconds based on the subcommand
        let totalSeconds, updateInterval, displayUnit;
        
        switch (subcommand) {
            case 'seconds':
                totalSeconds = amount;
                updateInterval = 1000; // Update every second
                displayUnit = 'seconds';
                break;
            case 'minutes':
                totalSeconds = amount * 60;
                updateInterval = 60000; // Update every minute
                displayUnit = 'minutes';
                break;
            case 'hours':
                totalSeconds = amount * 60 * 60;
                updateInterval = 300000; // Update every 5 minutes
                displayUnit = 'hours';
                break;
            case 'days':
                totalSeconds = amount * 24 * 60 * 60;
                updateInterval = 3600000; // Update every hour
                displayUnit = 'days';
                break;
        }
        
        // Format time for display
        const formatTime = (seconds) => {
            if (subcommand === 'seconds') {
                return `${seconds} seconds`;
            } else if (subcommand === 'minutes') {
                const minutes = Math.floor(seconds / 60);
                const remainingSeconds = seconds % 60;
                return `${minutes} minutes ${remainingSeconds > 0 ? `and ${remainingSeconds} seconds` : ''}`;
            } else if (subcommand === 'hours') {
                const hours = Math.floor(seconds / 3600);
                const minutes = Math.floor((seconds % 3600) / 60);
                return `${hours} hours ${minutes > 0 ? `and ${minutes} minutes` : ''}`;
            } else if (subcommand === 'days') {
                const days = Math.floor(seconds / 86400);
                const hours = Math.floor((seconds % 86400) / 3600);
                return `${days} days ${hours > 0 ? `and ${hours} hours` : ''}`;
            }
        };
        
        // Acknowledge the command first
        await interaction.reply({ 
            content: `Starting a ${amount} ${displayUnit} countdown...`, 
            ephemeral: true 
        });
        
        try {
            // Send the initial countdown message
            const initialTimeDisplay = formatTime(totalSeconds);
            // Format the countdown message based on custom format and optional during_message
            let formattedCountdownMsg;
            if (duringMessage && !countdownFormat.includes('{message}')) {
                // If there's a during_message but no {message} placeholder in the format, use the old style
                formattedCountdownMsg = `${duringMessage} ${initialTimeDisplay}`;
            } else {
                // Replace both placeholders if they exist
                formattedCountdownMsg = countdownFormat
                    .replace('{time}', initialTimeDisplay)
                    .replace('{message}', duringMessage || 'Countdown:');
            }
            
            // Also update the countdown text in the config if this was successful
            // This makes this text available via the {countdown-text} placeholder
            if (interaction.client.config && interaction.client.config.countdownFormat) {
                const updatedText = `${countdownFormat
                    .replace('{time}', initialTimeDisplay)
                    .replace('{message}', duringMessage || 'Countdown:')}`;
                
                if (typeof interaction.client.config.countdownFormat === 'object') {
                    interaction.client.config.countdownFormat.text = updatedText;
                }
            }
            
            const countdownMessage = await interaction.channel.send(formattedCountdownMsg);
            
            // For short countdowns (seconds), update more frequently
            if (subcommand === 'seconds') {
                // Run the countdown
                for (let i = totalSeconds - 1; i >= 0; i--) {
                    // Wait 1 second
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    
                    // Update the countdown message
                    if (i > 0) {
                        const timeText = `${i} seconds`;
                        let newMessage;
                        if (duringMessage && !countdownFormat.includes('{message}')) {
                            newMessage = `${duringMessage} ${timeText}`;
                        } else {
                            newMessage = countdownFormat
                                .replace('{time}', timeText)
                                .replace('{message}', duringMessage || 'Countdown:');
                        }
                        await countdownMessage.edit(newMessage);
                        
                        // Also update the countdown text in the config
                        if (interaction.client.config && interaction.client.config.countdownFormat && typeof interaction.client.config.countdownFormat === 'object') {
                            interaction.client.config.countdownFormat.text = newMessage;
                        }
                    } else {
                        // Last message with the custom text
                        await countdownMessage.edit(message);
                    }
                }
            } else {
                // For longer countdowns, use setInterval and setTimeout
                const endTime = Date.now() + (totalSeconds * 1000);
                
                // Create an interval to update the message periodically
                const intervalId = setInterval(async () => {
                    const remainingSeconds = Math.ceil((endTime - Date.now()) / 1000);
                    
                    if (remainingSeconds > 0) {
                        const timeText = formatTime(remainingSeconds);
                        let newMessage;
                        if (duringMessage && !countdownFormat.includes('{message}')) {
                            newMessage = `${duringMessage} ${timeText}`;
                        } else {
                            newMessage = countdownFormat
                                .replace('{time}', timeText)
                                .replace('{message}', duringMessage || 'Countdown:');
                        }
                        await countdownMessage.edit(newMessage);
                        
                        // Also update the countdown text in the config
                        if (interaction.client.config && interaction.client.config.countdownFormat && typeof interaction.client.config.countdownFormat === 'object') {
                            interaction.client.config.countdownFormat.text = newMessage;
                        }
                    }
                }, updateInterval);
                
                // Set a timeout to clear the interval and post the final message
                setTimeout(async () => {
                    clearInterval(intervalId);
                    await countdownMessage.edit(message);
                }, totalSeconds * 1000);
            }
        } catch (error) {
            console.error('Error in countdown command:', error);
            
            await interaction.followUp({
                content: `Failed to complete the countdown: ${error.message}`,
                ephemeral: true
            });
        }
    }
};