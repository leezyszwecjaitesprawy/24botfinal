const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const logger = require('../../utils/logger');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-membercount')
        .setDescription('Sets up a member count channel')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Set up a member count channel')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('The voice channel to use for member count (defaults to creating a new one)')
                        .addChannelTypes(ChannelType.GuildVoice)
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('format')
                        .setDescription('The format for the member count display')
                        .setRequired(false)
                        .addChoices(
                            { name: '👥︲{count} Members', value: '👥︲{count} Members' },
                            { name: '👥│{count} MEMBERS', value: '👥│{count} MEMBERS' },
                            { name: 'Members: {count}', value: 'Members: {count}' },
                            { name: 'Users: {count}', value: 'Users: {count}' },
                            { name: '👤 {count}', value: '👤 {count}' },
                            { name: '{count} members', value: '{count} members' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('custom')
                .setDescription('Set a custom format for the member count channel')
                .addStringOption(option =>
                    option.setName('format')
                        .setDescription('Custom format (use {count} as a placeholder for the member count)')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('disable')
                .setDescription('Disable the member count feature'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Defer reply while we process the action
        await interaction.deferReply({ ephemeral: true });
        
        try {
            const subcommand = interaction.options.getSubcommand();
            
            switch (subcommand) {
                case 'setup':
                    await this.setupMemberCount(interaction);
                    break;
                case 'custom':
                    await this.setCustomFormat(interaction);
                    break;
                case 'disable':
                    await this.disableMemberCount(interaction);
                    break;
                default:
                    await interaction.editReply({
                        content: 'Unknown subcommand. Please use setup, custom, or disable.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            console.error('Error in member count command:', error);
            
            await interaction.editReply({
                content: `Failed to execute command: ${error.message}`,
                ephemeral: true
            });
        }
    },
    
    // Setup a member count channel with predefined format
    async setupMemberCount(interaction) {
        try {
            // Get selected channel or create a new one
            let channel = interaction.options.getChannel('channel');
            
            if (!channel) {
                // Create a new voice channel for the member count
                channel = await interaction.guild.channels.create({
                    name: '👥︲Members',
                    type: ChannelType.GuildVoice,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: ['Connect'], // Nobody can connect to this voice channel
                            allow: ['ViewChannel']
                        }
                    ]
                });
                
                await interaction.editReply({
                    content: `Created a new member count channel: ${channel}`,
                    ephemeral: true
                });
            }
            
            // Set the channel permissions to prevent people from joining
            await channel.permissionOverwrites.edit(interaction.guild.id, {
                Connect: false,
                ViewChannel: true
            });
            
            // Get the format option
            const format = interaction.options.getString('format') || '👥│{count} MEMBERS';
            
            // Update the client configuration
            interaction.client.config.memberCountChannelId = channel.id;
            interaction.client.config.memberCountFormat = format;
            
            // Update the member count display
            await logger.updateMemberCount(interaction.client, interaction.guild);
            
            await interaction.editReply({
                content: `Member count channel set up successfully. Using format: ${format.replace('{count}', interaction.guild.memberCount)}`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error setting up member count:', error);
            throw error;
        }
    },
    
    // Set a custom format for the member count
    async setCustomFormat(interaction) {
        try {
            const customFormat = interaction.options.getString('format');
            
            // Validate that the format contains the {count} placeholder
            if (!customFormat.includes('{count}')) {
                return await interaction.editReply({
                    content: 'The custom format must include the {count} placeholder.',
                    ephemeral: true
                });
            }
            
            // Get the current member count channel ID
            const channelId = interaction.client.config.memberCountChannelId;
            let channel = null;
            
            if (channelId) {
                channel = interaction.guild.channels.cache.get(channelId);
            }
            
            // If no channel is set up yet, create one
            if (!channel) {
                channel = await interaction.guild.channels.create({
                    name: '👥︲Members',
                    type: ChannelType.GuildVoice,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: ['Connect'],
                            allow: ['ViewChannel']
                        }
                    ]
                });
                
                interaction.client.config.memberCountChannelId = channel.id;
            }
            
            // Update the format in the configuration
            interaction.client.config.memberCountFormat = customFormat;
            
            // Update the member count display
            await logger.updateMemberCount(interaction.client, interaction.guild);
            
            await interaction.editReply({
                content: `Member count format updated successfully. Preview: ${customFormat.replace('{count}', interaction.guild.memberCount)}`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error setting custom format:', error);
            throw error;
        }
    },
    
    // Disable the member count feature
    async disableMemberCount(interaction) {
        try {
            // Get the current member count channel
            const channelId = interaction.client.config.memberCountChannelId;
            
            if (!channelId) {
                return await interaction.editReply({
                    content: 'Member count feature is not currently enabled.',
                    ephemeral: true
                });
            }
            
            // Reset the configuration
            interaction.client.config.memberCountChannelId = null;
            
            await interaction.editReply({
                content: 'Member count feature has been disabled. The channel has not been deleted, but it will no longer be updated.',
                ephemeral: true
            });
        } catch (error) {
            console.error('Error disabling member count:', error);
            throw error;
        }
    }
};