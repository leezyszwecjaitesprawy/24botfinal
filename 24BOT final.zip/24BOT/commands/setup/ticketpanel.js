const { 
    SlashCommandBuilder, 
    PermissionFlagsBits,
    EmbedBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ComponentType
} = require('discord.js');

// Get the tickets component for panel creation
let ticketsComponent;

// Get the default panel options
const DEFAULT_PANEL_OPTIONS = {
    title: 'Support Tickets',
    description: '**Wybierz kategorię zgłoszenia, a następnie wypełnij formularz.**\n\nPo utworzeniu zgłoszenia, Admin <@&1141712746417762359> się z Tobą skontaktuje oraz zapozna się z twoim problemem. Prosimy o cierpliwość i oczekiwanie na odpowiedź.',
    categories: [
        { name: 'Proposition', value: 'proposition' },
        { name: 'Support', value: 'support' },
        { name: 'Mixing & Mastering services', value: 'mixing-mastering-services' },
        { name: 'Purchase a license', value: 'purchase-a-license' },
        { name: 'Other', value: 'other' }
    ]
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-ticketpanel')
        .setDescription('Set up custom ticket panel messages with advanced editor')
        .addSubcommand(subcommand =>
            subcommand
                .setName('advanced')
                .setDescription('Open the advanced ticket panel editor'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('send')
                .setDescription('Send a ticket panel to the current channel')
                .addStringOption(option =>
                    option.setName('title')
                        .setDescription('The title for the ticket panel')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('The description for the ticket panel')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('color')
                        .setDescription('The color for the ticket panel embed (hex format, e.g., #808080)')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('categories')
                        .setDescription('Ticket categories separated by commas (e.g., Support,License,Feedback)')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('category_id')
                        .setDescription('Discord channel category ID where tickets will be created')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('preview')
                .setDescription('Preview the current ticket panel configuration'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        try {
            // Check if the client has the components collection
            if (!interaction.client.components) {
                interaction.client.components = new Map();
                
                // Load the components from the components directory
                const fs = require('node:fs');
                const path = require('node:path');
                const componentsPath = path.join(__dirname, '..', '..', 'components');
                
                if (fs.existsSync(componentsPath)) {
                    const componentFiles = fs.readdirSync(componentsPath).filter(file => file.endsWith('.js'));
                    
                    for (const file of componentFiles) {
                        const filePath = path.join(componentsPath, file);
                        const component = require(filePath);
                        const componentName = path.parse(file).name;
                        
                        interaction.client.components.set(componentName, component);
                    }
                }
            }
            
            // Get the tickets component for panel creation
            if (!ticketsComponent) {
                ticketsComponent = interaction.client.components.get('tickets');
                if (!ticketsComponent) {
                    return await interaction.reply({
                        content: 'Error: Tickets component not found. Please make sure the tickets component is properly loaded.',
                        ephemeral: true
                    });
                }
            }
            
            const subcommand = interaction.options.getSubcommand();
            
            switch (subcommand) {
                case 'advanced':
                    await this.handleAdvancedEditor(interaction);
                    break;
                case 'send':
                    await this.handleSendPanel(interaction);
                    break;
                case 'preview':
                    await this.handlePreviewPanel(interaction);
                    break;
                default:
                    await interaction.reply({
                        content: 'Unknown subcommand.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            console.error('Error in setup-ticketpanel command:', error);
            
            await interaction.reply({
                content: `Failed to execute command: ${error.message}`,
                ephemeral: true
            });
        }
    },
    
    async handleAdvancedEditor(interaction) {
        await interaction.deferReply({ ephemeral: true });
        
        // Initialize panel settings if not exist
        if (!interaction.client.config.ticketPanel) {
            interaction.client.config.ticketPanel = { ...DEFAULT_PANEL_OPTIONS };
        }
        
        // Build the editor interface
        const editorEmbed = new EmbedBuilder()
            .setTitle('Advanced Ticket Panel Editor')
            .setDescription('Customize your ticket panel appearance. Select what you want to edit below.')
            .setColor('#0099ff')
            .addFields(
                { name: 'Available Options', value: 
                    '• **Title** - The title of the ticket panel embed\n' +
                    '• **Description** - The main content of the ticket panel\n' +
                    '• **Admin mention** - Tag a specific role to mention in the panel\n' +
                    '• **Categories** - Currently not editable via this interface'
                }
            );
        
        // Create buttons for each option
        const titleButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:edit:title')
            .setLabel('Edit Title')
            .setStyle(ButtonStyle.Primary);
            
        const descriptionButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:edit:description')
            .setLabel('Edit Description')
            .setStyle(ButtonStyle.Primary);
            
        const previewButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:preview')
            .setLabel('Preview Panel')
            .setStyle(ButtonStyle.Secondary);
            
        // Create rows for the buttons
        const buttonRow = new ActionRowBuilder().addComponents(titleButton, descriptionButton);
        const previewRow = new ActionRowBuilder().addComponents(previewButton);
        
        const response = await interaction.editReply({
            embeds: [editorEmbed],
            components: [buttonRow, previewRow],
            ephemeral: true
        });
        
        // Set up a collector for button interactions
        const collector = response.createMessageComponentCollector({ 
            time: 300000,  // 5 minutes
            componentType: ComponentType.Button
        });
        
        // Handle button presses
        collector.on('collect', async i => {
            const [prefix, action, field] = i.customId.split(':');
            
            if (prefix === 'ticketpanel_editor') {
                if (action === 'edit') {
                    // Handle editing different fields
                    if (field === 'title') {
                        // Create a modal for the title
                        const modal = new ModalBuilder()
                            .setCustomId('ticketpanel:title')
                            .setTitle('Edit Ticket Panel Title');
                            
                        const titleInput = new TextInputBuilder()
                            .setCustomId('ticketPanelTitle')
                            .setLabel('Panel Title')
                            .setPlaceholder('Enter the title for your ticket panel')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                            .setMaxLength(256);
                            
                        // Set current value if it exists
                        if (interaction.client.config.ticketPanel && interaction.client.config.ticketPanel.title) {
                            titleInput.setValue(interaction.client.config.ticketPanel.title);
                        } else {
                            titleInput.setValue(DEFAULT_PANEL_OPTIONS.title);
                        }
                        
                        const firstActionRow = new ActionRowBuilder().addComponents(titleInput);
                        modal.addComponents(firstActionRow);
                        
                        // Show the modal
                        await i.showModal(modal);
                    } else if (field === 'description') {
                        // Create a modal for the description
                        const modal = new ModalBuilder()
                            .setCustomId('ticketpanel:description')
                            .setTitle('Edit Ticket Panel Description');
                            
                        const descriptionInput = new TextInputBuilder()
                            .setCustomId('ticketPanelDescription')
                            .setLabel('Panel Description')
                            .setPlaceholder('Enter the description text for your ticket panel')
                            .setStyle(TextInputStyle.Paragraph)
                            .setRequired(true)
                            .setMaxLength(2000);
                            
                        // Set current value if it exists
                        if (interaction.client.config.ticketPanel && interaction.client.config.ticketPanel.description) {
                            descriptionInput.setValue(interaction.client.config.ticketPanel.description);
                        } else {
                            descriptionInput.setValue(DEFAULT_PANEL_OPTIONS.description);
                        }
                        
                        const firstActionRow = new ActionRowBuilder().addComponents(descriptionInput);
                        modal.addComponents(firstActionRow);
                        
                        // Show the modal
                        await i.showModal(modal);
                    }
                } else if (action === 'preview') {
                    await this.handlePreviewPanel(i);
                }
            }
        });
    },
    
    async handleSendPanel(interaction) {
        await interaction.deferReply({ ephemeral: true });
        
        // Get panel options from command or config
        const title = interaction.options.getString('title') || 
            (interaction.client.config.ticketPanel?.title || DEFAULT_PANEL_OPTIONS.title);
            
        const description = interaction.options.getString('description') || 
            (interaction.client.config.ticketPanel?.description || DEFAULT_PANEL_OPTIONS.description);
            
        // Get color option (default to dark gray if not specified)
        const color = interaction.options.getString('color') || '#808080';  // Dark gray as default
        
        // Get and process categories if provided
        let categories = DEFAULT_PANEL_OPTIONS.categories;
        const categoriesOption = interaction.options.getString('categories');
        
        if (categoriesOption) {
            // Split the categories string by commas
            const categoryNames = categoriesOption.split(',').map(cat => cat.trim());
            
            // Create category objects with values
            categories = categoryNames.map(name => {
                // Convert the name to a value (lowercase, replace spaces with hyphens)
                const value = name.toLowerCase().replace(/\s+/g, '-');
                return { name, value };
            });
        }
        
        // Create panel options
        const panelOptions = {
            title: title,
            description: description,
            categories: categories.map(category => category.name),
            color: color
        };
        
        // Get category ID for ticket creation if provided
        const categoryId = interaction.options.getString('category_id');
        
        // Save the panel configuration
        if (!interaction.client.config.ticketPanel) {
            interaction.client.config.ticketPanel = {};
        }
        interaction.client.config.ticketPanel.title = title;
        interaction.client.config.ticketPanel.description = description;
        interaction.client.config.ticketPanel.color = color;
        interaction.client.config.ticketPanel.categories = categories;
        
        // Save category ID if provided
        if (categoryId) {
            interaction.client.config.ticketCategoryId = categoryId;
        }
        
        // Save skip form categories configuration
        interaction.client.config.skipFormCategories = ['purchase-a-license', 'mixing-mastering-services'];
        
        // Create the panel using the tickets component
        const panel = ticketsComponent.createTicketPanel(panelOptions);
        
        // Send the panel to the channel
        await interaction.channel.send({
            embeds: panel.embeds,
            components: panel.components
        });
        
        // Confirm to the user
        let confirmMessage = 'Ticket panel has been sent to this channel with dark gray color and configured to skip forms for "Purchase a license" and "Mixing & Mastering services" categories!';
        
        if (categoryId) {
            confirmMessage += `\nTickets will be created in the channel category with ID: ${categoryId}`;
        }
        
        await interaction.editReply({
            content: confirmMessage,
            ephemeral: true
        });
    },
    
    async handlePreviewPanel(interaction) {
        // Get the current panel configuration
        const config = interaction.client.config.ticketPanel || DEFAULT_PANEL_OPTIONS;
        
        // Create panel with current settings
        const panel = ticketsComponent.createTicketPanel({
            title: config.title,
            description: config.description,
            // Extract just the name from the categories to make it compatible
            categories: DEFAULT_PANEL_OPTIONS.categories.map(category => category.name),
            color: config.color || '#808080' // Default to dark gray
        });
        
        // Add edit buttons
        const editTitleButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:edit:title')
            .setLabel('Edit Title')
            .setStyle(ButtonStyle.Primary);
            
        const editDescriptionButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:edit:description')
            .setLabel('Edit Description')
            .setStyle(ButtonStyle.Primary);
            
        const sendButton = new ButtonBuilder()
            .setCustomId('ticketpanel_editor:send')
            .setLabel('Send to Current Channel')
            .setStyle(ButtonStyle.Success);
            
        const buttonRow = new ActionRowBuilder().addComponents(editTitleButton, editDescriptionButton);
        const sendRow = new ActionRowBuilder().addComponents(sendButton);
        
        // If this is a component interaction, update the message
        if (interaction.isMessageComponent()) {
            await interaction.update({
                content: '**Preview of your ticket panel:**',
                embeds: panel.embeds,
                components: [panel.components[0], buttonRow, sendRow],
                ephemeral: true
            });
        } else {
            await interaction.reply({
                content: '**Preview of your ticket panel:**',
                embeds: panel.embeds,
                components: [panel.components[0], buttonRow, sendRow],
                ephemeral: true
            });
        }
        
        // Set up collector for the button interactions
        const response = await interaction.fetchReply();
        
        const collector = response.createMessageComponentCollector({
            time: 300000, // 5 minutes
            componentType: ComponentType.Button
        });
        
        collector.on('collect', async i => {
            const [prefix, action, field] = i.customId.split(':');
            
            if (prefix === 'ticketpanel_editor') {
                if (action === 'edit') {
                    // Forward to the edit handler
                    if (field === 'title' || field === 'description') {
                        // Reuse the existing edit buttons logic
                        const customId = `ticketpanel_editor:edit:${field}`;
                        const buttonInteraction = {
                            customId,
                            showModal: (modal) => i.showModal(modal)
                        };
                        
                        // Call the edit handler
                        const [_, action, field] = customId.split(':');
                        if (field === 'title') {
                            // Create a modal for the title
                            const modal = new ModalBuilder()
                                .setCustomId('ticketpanel:title')
                                .setTitle('Edit Ticket Panel Title');
                                
                            const titleInput = new TextInputBuilder()
                                .setCustomId('ticketPanelTitle')
                                .setLabel('Panel Title')
                                .setPlaceholder('Enter the title for your ticket panel')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                                .setMaxLength(256);
                                
                            // Set current value if it exists
                            if (interaction.client.config.ticketPanel && interaction.client.config.ticketPanel.title) {
                                titleInput.setValue(interaction.client.config.ticketPanel.title);
                            } else {
                                titleInput.setValue(DEFAULT_PANEL_OPTIONS.title);
                            }
                            
                            const firstActionRow = new ActionRowBuilder().addComponents(titleInput);
                            modal.addComponents(firstActionRow);
                            
                            // Show the modal
                            await i.showModal(modal);
                        } else if (field === 'description') {
                            // Create a modal for the description
                            const modal = new ModalBuilder()
                                .setCustomId('ticketpanel:description')
                                .setTitle('Edit Ticket Panel Description');
                                
                            const descriptionInput = new TextInputBuilder()
                                .setCustomId('ticketPanelDescription')
                                .setLabel('Panel Description')
                                .setPlaceholder('Enter the description text for your ticket panel')
                                .setStyle(TextInputStyle.Paragraph)
                                .setRequired(true)
                                .setMaxLength(2000);
                                
                            // Set current value if it exists
                            if (interaction.client.config.ticketPanel && interaction.client.config.ticketPanel.description) {
                                descriptionInput.setValue(interaction.client.config.ticketPanel.description);
                            } else {
                                descriptionInput.setValue(DEFAULT_PANEL_OPTIONS.description);
                            }
                            
                            const firstActionRow = new ActionRowBuilder().addComponents(descriptionInput);
                            modal.addComponents(firstActionRow);
                            
                            // Show the modal
                            await i.showModal(modal);
                        }
                    }
                } else if (action === 'send') {
                    // Send the panel to the current channel
                    const config = interaction.client.config.ticketPanel || DEFAULT_PANEL_OPTIONS;
                    
                    // Create panel with current settings
                    const panel = ticketsComponent.createTicketPanel({
                        title: config.title,
                        description: config.description,
                        // Extract just the name from the categories to make it compatible
                        categories: DEFAULT_PANEL_OPTIONS.categories.map(category => category.name),
                        color: config.color || '#808080' // Default to dark gray
                    });
                    
                    // Send the panel
                    await interaction.channel.send({
                        embeds: panel.embeds,
                        components: panel.components
                    });
                    
                    // Confirm to the user
                    await i.update({
                        content: 'Ticket panel has been sent to this channel!',
                        embeds: [],
                        components: [],
                        ephemeral: true
                    });
                }
            }
        });
    }
};