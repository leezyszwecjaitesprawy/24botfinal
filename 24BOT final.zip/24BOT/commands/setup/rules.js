const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const rulesComponent = require('../../components/rules');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-rules')
        .setDescription('Sets up a rules channel with accept button')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to send the rules to')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to give when rules are accepted')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('The title of the rules embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('The content of the rules (supports markdown)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('button-label')
                .setDescription('The label for the accept button')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Defer reply while we process the setup
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Get options
            const channel = interaction.options.getChannel('channel');
            const role = interaction.options.getRole('role');
            const title = interaction.options.getString('title') || 'Server Rules';
            const description = interaction.options.getString('description') || 
                '**Please read and accept our server rules:**\n\n' +
                '1. Be respectful to all members\n' +
                '2. No spamming or flooding the channels\n' +
                '3. No offensive or inappropriate content\n' +
                '4. Keep discussions in the appropriate channels\n' +
                '5. Follow Discord\'s Terms of Service\n\n' +
                'By clicking the Accept button, you agree to follow these rules.';
            const buttonLabel = interaction.options.getString('button-label') || 'Accept Rules';
            
            // Check if the bot has permission to send messages in the target channel
            if (!channel.permissionsFor(interaction.client.user).has('SendMessages')) {
                return await interaction.editReply({
                    content: `I don't have permission to send messages in ${channel}.`,
                    ephemeral: true
                });
            }
            
            // Create the rules embed and button
            const rulesMessage = rulesComponent.createRulesEmbed({
                title,
                description,
                buttonLabel,
                roleId: role?.id
            });
            
            // Send the rules message
            await channel.send(rulesMessage);
            
            // Reply to the interaction
            await interaction.editReply({
                content: `Rules have been set up in ${channel}${role ? ` with the ${role.name} role` : ''}.`,
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error setting up rules:', error);
            
            await interaction.editReply({
                content: `Failed to set up rules: ${error.message}`,
                ephemeral: true
            });
        }
    }
};