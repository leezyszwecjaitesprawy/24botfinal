const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-voice')
        .setDescription('Sets up dynamic voice channels')
        .addChannelOption(option =>
            option.setName('category')
                .setDescription('The category to create the voice channels in')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('format')
                .setDescription('The format for the dynamic voice channels')
                .setRequired(false)
                .addChoices(
                    { name: '┇ {username}', value: '┇ {username}' },
                    { name: '🔊 {username}', value: '🔊 {username}' },
                    { name: 'Voice | {username}', value: 'Voice | {username}' }
                ))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Defer reply while we process the setup
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Get the category
            const category = interaction.options.getChannel('category');
            
            // Get the format option
            const format = interaction.options.getString('format') || '┇ {username}';
            
            // Create the "Create Channel" voice channel in the category
            const createChannel = await interaction.guild.channels.create({
                name: '➕ Create Channel',
                type: ChannelType.GuildVoice,
                parent: category.id,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        allow: ['ViewChannel', 'Connect'],
                    }
                ]
            });
            
            // Update the client configuration
            interaction.client.config.createChannelId = createChannel.id;
            interaction.client.config.voiceChannelFormat = format;
            
            await interaction.editReply({
                content: `Dynamic voice channel system set up successfully.\n` +
                         `- "Create Channel" voice channel: ${createChannel}\n` +
                         `- New channels will be created with format: ${format.replace('{username}', 'example')}`,
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error setting up dynamic voice channels:', error);
            
            await interaction.editReply({
                content: `Failed to set up dynamic voice channels: ${error.message}`,
                ephemeral: true
            });
        }
    }
};