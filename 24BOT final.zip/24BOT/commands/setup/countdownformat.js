const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-countdownformat')
        .setDescription('Configure the format of countdown messages')
        .setDefaultMemberPermissions(PermissionFlagsBits.ADMINISTRATOR)
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set a new format for countdown messages')
                .addStringOption(option =>
                    option.setName('format')
                        .setDescription('The format for countdown messages (use {time} as placeholder)')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('text')
                        .setDescription('Text to use in {countdown-text} placeholder in other messages (optional)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset')
                .setDescription('Reset countdown format to default')),

    async execute(interaction) {
        try {
            const subcommand = interaction.options.getSubcommand();
            let configPath = path.join(__dirname, '../../config.json');
            let config = {};
            
            // Check if config file exists and load it
            if (fs.existsSync(configPath)) {
                const configData = fs.readFileSync(configPath, 'utf8');
                config = JSON.parse(configData);
            } else {
                // Create default config if it doesn't exist
                config = {
                    adminRoleId: process.env.ADMIN_ROLE_ID,
                    logChannelId: process.env.LOG_CHANNEL_ID,
                    memberCountChannelId: process.env.MEMBER_COUNT_CHANNEL_ID,
                    createChannelId: process.env.CREATE_CHANNEL_ID,
                    countdownFormat: '⏱️ {time}'
                };
            }

            // Default format if not set or convert from string to object
            if (!config.countdownFormat) {
                config.countdownFormat = {
                    format: '⏱️ {time}',
                    text: null
                };
            } else if (typeof config.countdownFormat === 'string') {
                // Convert from legacy string format to object
                const format = config.countdownFormat;
                config.countdownFormat = {
                    format: format,
                    text: null
                };
            }

            if (subcommand === 'set') {
                const newFormat = interaction.options.getString('format');
                const text = interaction.options.getString('text');
                
                // Validate format contains the time placeholder
                if (!newFormat.includes('{time}')) {
                    return interaction.reply({
                        content: 'The format must include the `{time}` placeholder.',
                        ephemeral: true
                    });
                }
                
                // Inform about the message placeholder if not present
                const hasMessagePlaceholder = newFormat.includes('{message}');
                const infoMessage = hasMessagePlaceholder ? 
                    'Your format includes both `{time}` and `{message}` placeholders. The `{message}` will be replaced with the during_message option if provided.' :
                    'Your format only includes the `{time}` placeholder. You can also use `{message}` to include the during_message option in your format.';
                
                // Create or update the countdownFormat object in the config
                if (!config.countdownFormat || typeof config.countdownFormat === 'string') {
                    // Convert from string to object if needed
                    config.countdownFormat = {
                        format: newFormat,
                        text: text || null
                    };
                } else {
                    // Update existing object
                    config.countdownFormat.format = newFormat;
                    if (text !== null) {
                        config.countdownFormat.text = text;
                    }
                }
                
                // Also update client config
                if (interaction.client.config) {
                    if (!interaction.client.config.countdownFormat || typeof interaction.client.config.countdownFormat === 'string') {
                        interaction.client.config.countdownFormat = {
                            format: newFormat,
                            text: text || null
                        };
                    } else {
                        interaction.client.config.countdownFormat.format = newFormat;
                        if (text !== null) {
                            interaction.client.config.countdownFormat.text = text;
                        }
                    }
                }
                
                // Save updated config
                fs.writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                
                // Create preview embed
                const previewEmbed = new EmbedBuilder()
                    .setColor(0x2B2D31)
                    .setTitle('Countdown Format Updated')
                    .addFields(
                        { name: 'New Format', value: `\`${newFormat}\`` },
                        { name: 'Preview with time', value: newFormat.replace('{time}', '2 hours, 30 minutes').replace('{message}', 'Countdown:') }
                    )
                    
                // Add message placeholder preview if it exists
                if (hasMessagePlaceholder) {
                    previewEmbed.addFields(
                        { name: 'Preview with custom message', value: newFormat.replace('{time}', '2 hours, 30 minutes').replace('{message}', 'Server restart in:') }
                    );
                }
                
                // Add countdown text display if set
                if (text) {
                    previewEmbed.addFields(
                        { name: 'Countdown Text', value: `\`${text}\`` },
                        { name: 'Usage', value: 'This text will be available in the {countdown-text} placeholder for other messages, like ticket messages.' }
                    );
                }
                
                previewEmbed.addFields(
                    { name: 'Info', value: infoMessage }
                )
                .setFooter({ text: 'Format will apply to all new countdowns' });
                
                await interaction.reply({
                    embeds: [previewEmbed]
                });
            } else if (subcommand === 'reset') {
                // Reset to default object with format and empty text
                config.countdownFormat = {
                    format: '⏱️ {time}',
                    text: null
                };
                
                // Also update client config
                if (interaction.client.config) {
                    interaction.client.config.countdownFormat = {
                        format: '⏱️ {time}',
                        text: null
                    };
                }
                
                // Save updated config
                fs.writeFileSync(configPath, JSON.stringify(config, null, 4), 'utf8');
                
                await interaction.reply({
                    content: 'Countdown format reset to default: `⏱️ {time}`',
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error('Error in setup-countdownformat command:', error);
            await interaction.reply({
                content: `Failed to update countdown format: ${error.message}`,
                ephemeral: true
            });
        }
    }
};