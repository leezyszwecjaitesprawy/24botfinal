const { 
    SlashCommandBuilder, 
    PermissionFlagsBits,
    EmbedBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ComponentType
} = require('discord.js');

// Category options for consistent reference
const TICKET_CATEGORIES = [
    { name: 'Proposition', value: 'proposition' },
    { name: 'Support', value: 'support' },
    { name: 'Mixing & Mastering services', value: 'mixing-mastering-services' },
    { name: 'Purchase a license', value: 'purchase-a-license' },
    { name: 'Other', value: 'other' }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-ticketmessage')
        .setDescription('Set up custom opening messages for ticket categories')
        .addSubcommand(subcommand =>
            subcommand
                .setName('advanced')
                .setDescription('Open the advanced ticket message editor'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set a custom message for a ticket category')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('The ticket category to set a message for')
                        .setRequired(true)
                        .addChoices(...TICKET_CATEGORIES))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('The message to send when a ticket is created')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('view')
                .setDescription('View current custom ticket messages'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove a custom ticket message')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('The ticket category to remove the message for')
                        .setRequired(true)
                        .addChoices(...TICKET_CATEGORIES)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        try {
            const subcommand = interaction.options.getSubcommand();
            
            switch (subcommand) {
                case 'advanced':
                    await this.handleAdvancedEditor(interaction);
                    break;
                case 'set':
                    await this.handleSetMessage(interaction);
                    break;
                case 'view':
                    await this.handleViewMessages(interaction);
                    break;
                case 'remove':
                    await this.handleRemoveMessage(interaction);
                    break;
                default:
                    await interaction.reply({
                        content: 'Unknown subcommand.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            console.error('Error in setup-ticketmessage command:', error);
            
            await interaction.reply({
                content: `Failed to execute command: ${error.message}`,
                ephemeral: true
            });
        }
    },
    
    async handleAdvancedEditor(interaction) {
        // Create ticket messages object if it doesn't exist
        if (!interaction.client.config.ticketMessages) {
            interaction.client.config.ticketMessages = {};
        }
        
        await interaction.deferReply({ ephemeral: true });
        
        // Build the editor interface
        const editorEmbed = new EmbedBuilder()
            .setTitle('Advanced Ticket Message Editor')
            .setDescription('Select a category to edit its ticket message. After selecting a category, you\'ll be able to use the advanced editor to craft your message with rich formatting.')
            .setColor('#0099ff')
            .addFields(
                { name: 'Available Placeholders', value: 
                    '`{user}` - Mentions the ticket creator\n' +
                    '`{admin}` - Mentions the admin role\n' +
                    '`{ticket-id}` - Shows the ticket number\n' +
                    '`{category}` - Shows the ticket category name\n' +
                    '`{countdown-text}` - Shows the current countdown text'
                }
            );
        
        // Create a select menu for category selection    
        const categorySelect = new StringSelectMenuBuilder()
            .setCustomId('ticketmessage_editor:select_category')
            .setPlaceholder('Select a category to edit')
            .addOptions(TICKET_CATEGORIES.map(category => ({
                label: category.name,
                value: category.value,
                description: `Edit message for ${category.name} category`,
            })));
            
        // Create a button to view current messages
        const viewButton = new ButtonBuilder()
            .setCustomId('ticketmessage_editor:view')
            .setLabel('View Current Messages')
            .setStyle(ButtonStyle.Secondary);
            
        // Create a row for the category select
        const selectRow = new ActionRowBuilder().addComponents(categorySelect);
        // Create a row for the view button
        const buttonRow = new ActionRowBuilder().addComponents(viewButton);
        
        const response = await interaction.editReply({
            embeds: [editorEmbed],
            components: [selectRow, buttonRow],
            ephemeral: true
        });
        
        // Set up a collector for interactions
        const collector = response.createMessageComponentCollector({ 
            time: 300000,  // 5 minutes
            componentType: ComponentType.StringSelect
        });
        
        // Handle category selection
        collector.on('collect', async i => {
            if (i.customId === 'ticketmessage_editor:select_category') {
                const categoryValue = i.values[0];
                const categoryName = TICKET_CATEGORIES.find(cat => cat.value === categoryValue).name;
                
                // Create a modal for the ticket message
                const modal = new ModalBuilder()
                    .setCustomId(`ticketmessage:${categoryValue}`)
                    .setTitle(`Ticket Message for ${categoryName}`);
                    
                // Create a text input with improved documentation for placeholders
                const messageInput = new TextInputBuilder()
                    .setCustomId('ticketMessageContent')
                    .setLabel('Message Content')
                    .setPlaceholder(`Type your message using placeholders like {user}, {admin}, {ticket-id}...`)
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
                    .setMaxLength(2000);
                    
                // If there's a current message for this category, pre-fill it
                if (interaction.client.config.ticketMessages && interaction.client.config.ticketMessages[categoryValue]) {
                    messageInput.setValue(interaction.client.config.ticketMessages[categoryValue]);
                }
                
                const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
                modal.addComponents(firstActionRow);
                
                // Show the modal
                await i.showModal(modal);
            }
        });
        
        // Set up a button collector
        const buttonCollector = response.createMessageComponentCollector({
            time: 300000,  // 5 minutes
            componentType: ComponentType.Button
        });
        
        // Handle button interactions
        buttonCollector.on('collect', async i => {
            if (i.customId === 'ticketmessage_editor:view') {
                await this.handleViewMessages(i);
            }
        });
    },
    
    async handleSetMessage(interaction) {
        await interaction.deferReply({ ephemeral: true });
        
        const category = interaction.options.getString('category');
        const message = interaction.options.getString('message');
        
        // Get category name for display
        const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category).name;
        
        // If no message was provided, show the modal for advanced editing
        if (!message) {
            // Create a modal for the ticket message
            const modal = new ModalBuilder()
                .setCustomId(`ticketmessage:${category}`)
                .setTitle(`Ticket Message for ${categoryName}`);
                
            // Create a text input with improved documentation for placeholders
            const messageInput = new TextInputBuilder()
                .setCustomId('ticketMessageContent')
                .setLabel('Message Content')
                .setPlaceholder(`Type your message using placeholders like {user}, {admin}, {ticket-id}...`)
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true)
                .setMaxLength(2000);
                
            // If there's a current message for this category, pre-fill it
            if (interaction.client.config.ticketMessages && interaction.client.config.ticketMessages[category]) {
                messageInput.setValue(interaction.client.config.ticketMessages[category]);
            }
            
            const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
            modal.addComponents(firstActionRow);
            
            // Delete the deferred reply (if possible)
            try {
                await interaction.deleteReply();
            } catch (error) {
                console.error('Could not delete deferred reply:', error);
            }
            
            // Show the modal
            return await interaction.showModal(modal);
        }
        
        // Initialize ticketMessages object if it doesn't exist
        if (!interaction.client.config.ticketMessages) {
            interaction.client.config.ticketMessages = {};
        }
        
        // Save the message for this category
        interaction.client.config.ticketMessages[category] = message;
        
        // Create a preview for the confirmation message
        let messagePreview = message;
        const previewMaxLength = 200;
        if (message.length > previewMaxLength) {
            let cutoffIndex = message.substring(0, previewMaxLength).lastIndexOf('\n');
            if (cutoffIndex === -1 || cutoffIndex < previewMaxLength / 2) {
                cutoffIndex = previewMaxLength - 3;
            }
            messagePreview = message.substring(0, cutoffIndex) + '...';
        }
        
        // Show a preview of how placeholders would be rendered
        let examplePreview = message
            .replace(/{user}/g, '@user')
            .replace(/{admin}/g, '@admin')
            .replace(/{ticket-id}/g, '123')
            .replace(/{category}/g, categoryName);
            
        // Handle countdown text placeholder if exists
        if (examplePreview.includes('{countdown-text}')) {
            if (interaction.client.config.countdownFormat) {
                if (typeof interaction.client.config.countdownFormat === 'object' && interaction.client.config.countdownFormat.text) {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, interaction.client.config.countdownFormat.text);
                } else if (typeof interaction.client.config.countdownFormat === 'string') {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, interaction.client.config.countdownFormat);
                } else {
                    examplePreview = examplePreview.replace(/{countdown-text}/g, 'Countdown not set');
                }
            } else {
                examplePreview = examplePreview.replace(/{countdown-text}/g, 'Countdown not set');
            }
        }
        
        // Prepare the preview embed
        const previewEmbed = new EmbedBuilder()
            .setTitle(`Message for ${categoryName} Tickets`)
            .setDescription(examplePreview)
            .setColor('#0099ff')
            .setFooter({ text: 'Preview with placeholder substitution' });
        
        await interaction.editReply({
            content: `Custom message set for ${categoryName} tickets.`,
            embeds: [previewEmbed],
            ephemeral: true
        });
    },
    
    async handleViewMessages(interaction) {
        const ticketMessages = interaction.client.config.ticketMessages || {};
        
        if (Object.keys(ticketMessages).length === 0) {
            return await interaction.reply({
                content: 'No custom ticket messages have been set.',
                ephemeral: true
            });
        }
        
        // Create an embed to display all messages
        const embed = new EmbedBuilder()
            .setTitle('Custom Ticket Messages')
            .setColor('#00a8ff')
            .setDescription('The following custom messages are configured for ticket categories:');
            
        // Add each message as a field
        for (const [category, message] of Object.entries(ticketMessages)) {
            // Get the display name for the category
            const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
            
            // Format the message for display (truncate if needed)
            const displayMessage = message.length > 1024 ? message.substring(0, 1021) + '...' : message;
            
            embed.addFields({
                name: categoryName,
                value: displayMessage
            });
        }
        
        // Create edit buttons for each category that has a message
        const components = [];
        const buttons = [];
        
        // Add an edit and remove button for each category with a message
        Object.keys(ticketMessages).forEach((category, index) => {
            const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
            
            const editButton = new ButtonBuilder()
                .setCustomId(`ticketmessage_editor:edit:${category}`)
                .setLabel(`Edit ${categoryName}`)
                .setStyle(ButtonStyle.Primary);
                
            const removeButton = new ButtonBuilder()
                .setCustomId(`ticketmessage_editor:remove:${category}`)
                .setLabel(`Remove ${categoryName}`)
                .setStyle(ButtonStyle.Danger);
                
            buttons.push(editButton, removeButton);
            
            // Create new action row every 2 categories (4 buttons)
            if (buttons.length === 4 || index === Object.keys(ticketMessages).length - 1) {
                components.push(new ActionRowBuilder().addComponents(buttons.splice(0, buttons.length)));
            }
        });
        
        // If this is a component interaction, we need to update the message instead of replying
        if (interaction.isMessageComponent()) {
            await interaction.update({
                embeds: [embed],
                components: components.length > 0 ? components : [],
                ephemeral: true
            });
        } else {
            await interaction.reply({
                embeds: [embed],
                components: components.length > 0 ? components : [],
                ephemeral: true
            });
        }
        
        // Only set up the collector if we have components
        if (components.length > 0) {
            const response = await interaction.fetchReply();
            
            // Set up a collector for the buttons
            const collector = response.createMessageComponentCollector({ 
                componentType: ComponentType.Button,
                time: 300000 // 5 minutes
            });
            
            collector.on('collect', async i => {
                const [prefix, action, category] = i.customId.split(':');
                
                if (prefix === 'ticketmessage_editor') {
                    if (action === 'edit') {
                        const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
                        
                        // Create a modal for editing
                        const modal = new ModalBuilder()
                            .setCustomId(`ticketmessage:${category}`)
                            .setTitle(`Edit Message for ${categoryName}`);
                            
                        const messageInput = new TextInputBuilder()
                            .setCustomId('ticketMessageContent')
                            .setLabel('Message Content')
                            .setPlaceholder(`Type your message using placeholders like {user}, {admin}, {ticket-id}...`)
                            .setStyle(TextInputStyle.Paragraph)
                            .setRequired(true)
                            .setMaxLength(2000)
                            .setValue(interaction.client.config.ticketMessages[category]);
                            
                        const firstActionRow = new ActionRowBuilder().addComponents(messageInput);
                        modal.addComponents(firstActionRow);
                        
                        // Show the modal
                        await i.showModal(modal);
                    } else if (action === 'remove') {
                        // Remove the message
                        delete interaction.client.config.ticketMessages[category];
                        
                        const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
                        
                        // Update the message
                        await i.update({
                            content: `Custom message removed for ${categoryName} tickets. Refreshing view...`,
                            embeds: [],
                            components: [],
                            ephemeral: true
                        });
                        
                        // Update the view after a short delay
                        setTimeout(() => {
                            this.handleViewMessages(i);
                        }, 1000);
                    }
                }
            });
        }
    },
    
    async handleRemoveMessage(interaction) {
        const category = interaction.options.getString('category');
        
        // Get category name for display
        const categoryName = TICKET_CATEGORIES.find(cat => cat.value === category)?.name || category;
        
        // Check if there's a message for this category
        if (!interaction.client.config.ticketMessages || !interaction.client.config.ticketMessages[category]) {
            return await interaction.reply({
                content: `No custom message exists for ${categoryName} tickets.`,
                ephemeral: true
            });
        }
        
        // Remove the message
        delete interaction.client.config.ticketMessages[category];
        
        await interaction.reply({
            content: `Custom message removed for ${categoryName} tickets.`,
            ephemeral: true
        });
    }
};