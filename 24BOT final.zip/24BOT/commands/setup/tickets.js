const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const ticketsComponent = require('../../components/tickets');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-tickets')
        .setDescription('Sets up a ticket system with category selection')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to send the ticket panel to')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('The title of the ticket panel')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('The description of the ticket panel')
                .setRequired(false))
        .addChannelOption(option =>
            option.setName('create-category')
                .setDescription('The category to create ticket channels in')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Defer reply while we process the setup
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Get options
            const channel = interaction.options.getChannel('channel');
            const createCategory = interaction.options.getChannel('create-category');
            const title = interaction.options.getString('title') || 'Support Tickets';
            const description = interaction.options.getString('description') || 
                'Please select a category below to create a ticket. A staff member will assist you as soon as possible.';
            
            // Store the create category ID in the client config if provided
            if (createCategory) {
                interaction.client.config.ticketCategoryId = createCategory.id;
            }
            
            // Check if the bot has permission to send messages in the target channel
            if (!channel.permissionsFor(interaction.client.user).has('SendMessages')) {
                return await interaction.editReply({
                    content: `I don't have permission to send messages in ${channel}.`,
                    ephemeral: true
                });
            }
            
            // Create the ticket panel
            const ticketPanel = ticketsComponent.createTicketPanel({
                title,
                description,
                categories: [
                    'Proposition',
                    'Support',
                    'Mixing & Mastering services',
                    'Purchase a license',
                    'Other'
                ]
            });
            
            // Send the ticket panel
            await channel.send(ticketPanel);
            
            // Reply to the interaction
            await interaction.editReply({
                content: `Ticket system has been set up in ${channel}${createCategory ? ` with tickets created in ${createCategory}` : ''}.`,
                ephemeral: true
            });
            
        } catch (error) {
            console.error('Error setting up ticket system:', error);
            
            await interaction.editReply({
                content: `Failed to set up ticket system: ${error.message}`,
                ephemeral: true
            });
        }
    }
};