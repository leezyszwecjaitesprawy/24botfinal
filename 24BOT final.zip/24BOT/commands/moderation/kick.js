const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kicks a user from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to kick')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the kick')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
    
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        
        // Defer reply to have more time to process
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Make sure the user exists and is in the guild
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            
            if (!member) {
                return await interaction.editReply({
                    content: 'That user is not in this server.',
                    ephemeral: true
                });
            }
            
            // Check if the user is kickable
            if (!member.kickable) {
                return await interaction.editReply({ 
                    content: 'I do not have permission to kick this user. They may have higher permissions than me.',
                    ephemeral: true
                });
            }
            
            // Check if the user is trying to kick themselves
            if (member.id === interaction.user.id) {
                return await interaction.editReply({
                    content: 'You cannot kick yourself.',
                    ephemeral: true
                });
            }
            
            // Check if the user is trying to kick someone with higher roles
            if (interaction.member.roles.highest.position <= member.roles.highest.position) {
                return await interaction.editReply({
                    content: 'You cannot kick this user as they have the same or higher role than you.',
                    ephemeral: true
                });
            }
            
            // Kick the user
            await member.kick(`${reason} (Kicked by ${interaction.user.tag})`);
            
            // Log the kick
            await logger.logModeration(interaction.client, {
                type: 'kick',
                user: user,
                moderator: interaction.user,
                reason: reason
            });
            
            // Reply to the interaction
            await interaction.editReply({
                content: `Kicked`,
                ephemeral: true
            });
        } catch (error) {
            console.error(`Error kicking user ${user.tag}:`, error);
            
            await interaction.editReply({
                content: `Failed to kick ${user.tag}: ${error.message}`,
                ephemeral: true
            });
        }
    }
};