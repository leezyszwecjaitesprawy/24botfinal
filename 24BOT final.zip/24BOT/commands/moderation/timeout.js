const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Times out a user for a specified duration')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to timeout')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('Duration of the timeout in minutes')
                .setRequired(true)
                .addChoices(
                    { name: '1 minute', value: 1 },
                    { name: '5 minutes', value: 5 },
                    { name: '10 minutes', value: 10 },
                    { name: '30 minutes', value: 30 },
                    { name: '1 hour', value: 60 },
                    { name: '2 hours', value: 120 },
                    { name: '6 hours', value: 360 },
                    { name: '12 hours', value: 720 },
                    { name: '1 day', value: 1440 },
                    { name: '3 days', value: 4320 },
                    { name: '1 week', value: 10080 },
                ))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the timeout')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const durationMinutes = interaction.options.getInteger('duration');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        
        // Convert minutes to milliseconds for the Discord API
        const durationMs = durationMinutes * 60 * 1000;
        
        // Get human-readable duration for logging
        const humanReadableDuration = this.getHumanReadableDuration(durationMinutes);
        
        // Defer reply to have more time to process
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Make sure the user exists and is in the guild
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            
            if (!member) {
                return await interaction.editReply({
                    content: 'That user is not in this server.',
                    ephemeral: true
                });
            }
            
            // Check if the user can be timed out
            if (!member.moderatable) {
                return await interaction.editReply({ 
                    content: 'I do not have permission to timeout this user. They may have higher permissions than me.',
                    ephemeral: true
                });
            }
            
            // Check if the user is trying to timeout themselves
            if (member.id === interaction.user.id) {
                return await interaction.editReply({
                    content: 'You cannot timeout yourself.',
                    ephemeral: true
                });
            }
            
            // Check if the user is trying to timeout someone with higher roles
            if (interaction.member.roles.highest.position <= member.roles.highest.position) {
                return await interaction.editReply({
                    content: 'You cannot timeout this user as they have the same or higher role than you.',
                    ephemeral: true
                });
            }
            
            // Apply the timeout
            await member.timeout(durationMs, `${reason} (Timed out by ${interaction.user.tag})`);
            
            // Log the timeout
            await logger.logModeration(interaction.client, {
                type: 'timeout',
                user: user,
                moderator: interaction.user,
                reason: reason,
                duration: humanReadableDuration
            });
            
            // Reply to the interaction
            await interaction.editReply({
                content: `Timeouted`,
                ephemeral: true
            });
        } catch (error) {
            console.error(`Error timing out user ${user.tag}:`, error);
            
            await interaction.editReply({
                content: `Failed to timeout ${user.tag}: ${error.message}`,
                ephemeral: true
            });
        }
    },
    
    // Helper function to convert minutes to human-readable format
    getHumanReadableDuration(minutes) {
        if (minutes < 60) {
            return `${minutes} minut${minutes !== 1 ? '' : 'e'}`;
        } else if (minutes < 1440) {
            const hours = Math.floor(minutes / 60);
            const remainingMinutes = minutes % 60;
            if (remainingMinutes === 0) {
                return `${hours} godzin${hours === 1 ? 'a' : (hours < 5 ? 'y' : '')}`;
            } else {
                return `${hours} godzin${hours === 1 ? 'a' : (hours < 5 ? 'y' : '')} i ${remainingMinutes} minut${remainingMinutes === 1 ? 'a' : ''}`;
            }
        } else {
            const days = Math.floor(minutes / 1440);
            const remainingHours = Math.floor((minutes % 1440) / 60);
            if (remainingHours === 0) {
                return `${days} dni${days === 1 ? 'eń' : ''}`;
            } else {
                return `${days} dni${days === 1 ? 'eń' : ''} i ${remainingHours} godzin${remainingHours === 1 ? 'a' : (remainingHours < 5 ? 'y' : '')}`;
            }
        }
    }
};