const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Clears a specified number of messages from the channel')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of messages to delete (1-100)')
                .setMinValue(1)
                .setMaxValue(100)
                .setRequired(true))
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Only delete messages from this user')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    
    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');
        const user = interaction.options.getUser('user');
        
        // Defer reply to have more time to process
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Fetching extra messages in case of user filter
            const messagesToFetch = user ? Math.min(amount * 2, 100) : amount;
            
            // Get messages from the channel
            const messages = await interaction.channel.messages.fetch({ limit: messagesToFetch });
            
            // Filter messages if user is specified
            let messagesToDelete = messages;
            if (messagesToDelete.size > amount) {
                messagesToDelete = new Map([...messagesToDelete.entries()].slice(0, amount));
            }
            
            if (user) {
                messagesToDelete = messages.filter(m => m.author.id === user.id);
                
                // Limit to the requested amount
                if (messagesToDelete.size > amount) {
                    messagesToDelete = new Map([...messagesToDelete.entries()].slice(0, amount));
                }
            }
            
            // Discord restricts bulk deletion to messages newer than 14 days
            const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
            const recentMessages = messagesToDelete.filter(m => m.createdTimestamp > twoWeeksAgo);
            
            // Check if we have any messages to delete
            if (recentMessages.size === 0) {
                return await interaction.editReply({
                    content: 'No messages matched the criteria or all messages are older than 2 weeks.',
                    ephemeral: true
                });
            }
            
            // Delete messages
            const deletedCount = await interaction.channel.bulkDelete(recentMessages, true)
                .then(deleted => deleted.size);
            
            // Reply to the interaction
            const replyContent = user 
                ? `Successfully deleted ${deletedCount} message(s) from ${user.tag}.`
                : `Successfully deleted ${deletedCount} message(s).`;
                
            if (deletedCount < amount) {
                await interaction.editReply({
                    content: `${replyContent} Some messages could not be deleted (they may be older than 2 weeks).`,
                    ephemeral: true
                });
            } else {
                await interaction.editReply({
                    content: replyContent,
                    ephemeral: true
                });
            }
        } catch (error) {
            console.error('Error clearing messages:', error);
            
            await interaction.editReply({
                content: `Failed to clear messages: ${error.message}`,
                ephemeral: true
            });
        }
    }
};