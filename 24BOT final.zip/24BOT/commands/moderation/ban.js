const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bans a user from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to ban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the ban')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('delete-messages')
                .setDescription('Delete recent messages from this user')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
    
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const deleteMessages = interaction.options.getBoolean('delete-messages') || false;
        
        // Defer reply to have more time to process
        await interaction.deferReply({ ephemeral: true });
        
        try {
            // Make sure the user exists and is in the guild
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            
            // Check if the user is bannable
            if (member) {
                // Make sure the command user has permission to ban this member
                if (!member.bannable) {
                    return await interaction.editReply({ 
                        content: 'I do not have permission to ban this user. They may have higher permissions than me.',
                        ephemeral: true
                    });
                }
                
                // Check if the user is trying to ban themselves
                if (member.id === interaction.user.id) {
                    return await interaction.editReply({
                        content: 'You cannot ban yourself.',
                        ephemeral: true
                    });
                }
                
                // Check if the user is trying to ban someone with higher roles
                if (interaction.member.roles.highest.position <= member.roles.highest.position) {
                    return await interaction.editReply({
                        content: 'You cannot ban this user as they have the same or higher role than you.',
                        ephemeral: true
                    });
                }
            }
            
            // Set message deletion duration in days (0 = no deletion, 7 = maximum discord allows)
            const deleteDays = deleteMessages ? 7 : 0;
            
            // Ban the user
            await interaction.guild.members.ban(user, { 
                reason: `${reason} (Banned by ${interaction.user.tag})`,
                deleteMessageDays: deleteDays
            });
            
            // Log the ban
            await logger.logModeration(interaction.client, {
                type: 'ban',
                user: user,
                moderator: interaction.user,
                reason: reason
            });
            
            // Reply to the interaction
            await interaction.editReply({
                content: `Banned`,
                ephemeral: true
            });
        } catch (error) {
            console.error(`Error banning user ${user.tag}:`, error);
            
            await interaction.editReply({
                content: `Failed to ban ${user.tag}: ${error.message}`,
                ephemeral: true
            });
        }
    }
};