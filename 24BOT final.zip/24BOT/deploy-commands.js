const fs = require('node:fs');
const path = require('node:path');
const { REST, Routes } = require('discord.js');
require('dotenv').config();

// Get token and client ID from environment
const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;

// Check if token and client ID are provided
if (!token || !clientId) {
    console.error('Missing environment variables. Please set DISCORD_TOKEN and CLIENT_ID in .env file.');
    process.exit(1);
}

const commands = [];
// Load all command files from all subfolders
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
    const commandsPath = path.join(foldersPath, folder);
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    // Grab the SlashCommandBuilder#toJSON() output of each command's data for deployment
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            commands.push(command.data.toJSON());
            console.log(`Added command: ${command.data.name}`);
        } else {
            console.warn(`The command at ${filePath} is missing a required "data" or "execute" property.`);
        }
    }
}

// Construct and prepare an instance of the REST module
const rest = new REST().setToken(token);

// Deploy commands
(async () => {
    try {
        console.log(`Started refreshing ${commands.length} application (/) commands.`);
        
        const guildId = process.env.GUILD_ID;
        let data;
        
        if (guildId) {
            // If GUILD_ID is provided, register commands for a specific guild (faster for development)
            data = await rest.put(
                Routes.applicationGuildCommands(clientId, guildId),
                { body: commands },
            );
            console.log(`Successfully registered ${data.length} commands for guild ${guildId}.`);
        } else {
            // Register global commands (takes up to 1 hour to propagate)
            data = await rest.put(
                Routes.applicationCommands(clientId),
                { body: commands },
            );
            console.log(`Successfully registered ${data.length} global commands.`);
        }
        
    } catch (error) {
        console.error('Error deploying commands:', error);
    }
})();