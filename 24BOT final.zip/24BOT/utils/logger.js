const { EmbedBuilder } = require('discord.js');

module.exports = {
    /**
     * Logs a moderation action to the log channel
     * @param {Object} client - Discord client
     * @param {Object} options - Log options
     * @param {String} options.type - The type of log (ban, kick, etc.)
     * @param {Object} options.user - The user who was affected
     * @param {Object} options.moderator - The moderator who performed the action
     * @param {String} options.reason - The reason for the action
     * @param {String} options.duration - The duration of the action (for timeouts)
     */
    async logModeration(client, options) {
        try {
            const { type, user, moderator, reason, duration } = options;

            // Find the log channel
            const logChannelId = client.config.logChannelId;

            // For moderation logs, we need to handle guild reference properly
            let guild;

            if (moderator && moderator.guild) {
                // Get guild from moderator if available
                guild = moderator.guild;
            } else if (user && user.guild) {
                // Get guild from user if moderator doesn't have it
                guild = user.guild;
            } else {
                // Last resort - try to get first guild from client
                guild = client.guilds.cache.first();
            }

            if (!guild) return;

            const logChannel = guild.channels.cache.get(logChannelId);
            if (!logChannel) return;

            // Get message based on action type
            let message = '';

            switch (type.toLowerCase()) {
                case 'ban':
                    if (reason) {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴢʙᴀɴᴏᴡᴀɴʏ ᴘʀᴢᴇᴢ ${moderator} ᴢ ᴘᴏᴡᴏᴅᴜ **${reason}**`;
                    } else {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴢʙᴀɴᴏᴡᴀɴʏ ᴘʀᴢᴇᴢ ${moderator}`;
                    }
                    break;
                case 'unban':
                    if (moderator) {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴏᴅʙᴀɴᴏᴡᴀɴʏ ᴘʀᴢᴇᴢ ${moderator}`;
                    } else {
                        // If unbanned from server panel
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴏᴅʙᴀɴᴏᴡᴀɴʏ`;
                    }
                    break;
                case 'kick':
                    if (reason) {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴡʏʀᴢᴜᴄᴏɴʏ ᴘʀᴢᴇᴢ ${moderator} ᴢ ᴘᴏᴡᴏᴅᴜ **${reason}**`;
                    } else {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴡʏʀᴢᴜᴄᴏɴʏ ᴘʀᴢᴇᴢ ${moderator}`;
                    }
                    break;
                case 'timeout':
                    if (reason) {
                        message = `❗︲${user} ᴅᴏꜱᴛᴀʟ ᴛɪᴍᴇᴏᴜᴛᴀ ᴏᴅ ${moderator} ɴᴀ ${duration} ᴢ ᴘᴏᴡᴏᴅᴜ **${reason}**`;
                    } else {
                        message = `❗︲${user} ᴅᴏꜱᴛᴀʟ ᴛɪᴍᴇᴏᴜᴛᴀ ᴏᴅ ${moderator} ɴᴀ ${duration}`;
                    }
                    break;
                case 'leave':
                    message = `❗︲ ${user} ᴏᴘᴜꜱᴄɪʟ ꜱᴇʀᴡᴇʀ ᴊᴀᴋ ʙɪᴛʏ ᴄᴡᴇʟ`;
                    break;
                default:
                    if (reason) {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴢᴍᴏᴅᴇʀᴏᴡᴀɴʏ ᴘʀᴢᴇᴢ ${moderator} ᴢ ᴘᴏᴡᴏᴅᴜ ${reason}`;
                    } else {
                        message = `❗︲ ${user} ᴢᴏꜱᴛᴀʟ ᴢᴍᴏᴅᴇʀᴏᴡᴀɴʏ ᴘʀᴢᴇᴢ ${moderator}`;
                    }
            }

            // Send log message directly without embed
            await logChannel.send({ content: message });

        } catch (error) {
            console.error('Error logging moderation action:', error);
        }
    },

    /**
     * Logs a ticket action to the log channel
     * @param {Object} client - Discord client
     * @param {Object} options - Log options
     * @param {String} options.type - The type of ticket log (create, takeover, close)
     * @param {Object} options.user - The user who created the ticket
     * @param {Object} options.admin - The admin who performed the action
     * @param {Number} options.ticketId - The ticket ID
     * @param {String} options.category - The ticket category
     * @param {Object} options.channel - The ticket channel (for creation)
     * @param {String} options.transcriptAttachment - Path to the transcript attachment
     */
    async logTicket(client, options) {
        try {
            const { type, user, admin, ticketId, category, channel, transcriptAttachment } = options;

            // Find the log channel
            const logChannelId = client.config.logChannelId;

            // For ticket logs, we need to handle guild reference differently
            let guild;

            // For user objects from interactions, the guild is not directly attached
            if (user && user.client) {
                // For user-type objects with client reference (like client.user)
                guild = channel?.guild || user.client.guilds.cache.first();
            } else if (user && user.guild) {
                // For GuildMember objects
                guild = user.guild;
            } else if (admin && admin.guild) {
                // Try to get guild from admin if user doesn't have it
                guild = admin.guild;
            } else if (channel && channel.guild) {
                // Try to get guild from channel
                guild = channel.guild;
            } else {
                // Last resort - try to get first guild from client
                guild = client.guilds.cache.first();
            }

            if (!guild) return;

            const logChannel = guild.channels.cache.get(logChannelId);
            if (!logChannel) return;

            // Skip logging for 'close' action as requested
            if (type.toLowerCase() === 'close') {
                return; // Don't send anything for close action
            }

            // Get message based on action type
            let message = '';

            switch (type.toLowerCase()) {
                case 'create':
                    message = `❗︲ ${user} ꜱᴛᴡᴏʀᴢʏʟ ᴛɪᴄᴋᴇᴛ ⁠${channel} ᴡ ᴋᴀᴛᴇɢᴏʀɪɪ **${category}** ᴏ ɴᴜᴍᴇʀᴢᴇ **${ticketId}**`;
                    break;
                case 'takeover':
                    message = `❗︲ ${admin} ᴘʀᴢᴇᴊᴀʟ ᴛɪᴄᴋᴇᴛ ${user} ᴡ ᴋᴀᴛᴇɢᴏʀɪɪ **${category}** ᴏ ɴᴜᴍᴇʀᴢᴇ **${ticketId}**`;
                    break;
                case 'delete':
                    message = `❗︲ ${admin} ᴜꜱᴜɴᴀʟ ᴛɪᴄᴋᴇᴛ ${user} ᴡ ᴋᴀᴛᴇɢᴏʀɪɪ **${category}** ᴏ ɴᴜᴍᴇʀᴢᴇ **${ticketId}**`;
                    break;
                case 'close':
                    return; // Skip logging for close action
                default:
                    return; // Don't log unknown actions
            }

            // Check if there's a transcript attachment
            const messageOptions = { content: message };
            if (transcriptAttachment) {
                messageOptions.files = [transcriptAttachment];
            }
            await logChannel.send(messageOptions);

        } catch (error) {
            console.error('Error logging ticket action:', error);
        }
    },

    /**
     * Updates the member count channel
     * @param {Object} client - Discord client
     * @param {Object} guild - Discord guild
     */
    async updateMemberCount(client, guild) {
        try {
            const memberCountChannelId = client.config.memberCountChannelId;
            const memberCountFormat = client.config.memberCountFormat;

            if (!guild || !memberCountChannelId) return;

            const memberCountChannel = guild.channels.cache.get(memberCountChannelId);
            if (!memberCountChannel) return;

            // Get member count (excluding bots)
            const members = await guild.members.fetch();
            const memberCount = members.filter(member => !member.user.bot).size;

            // Update channel name
            const channelName = memberCountFormat.replace('{count}', memberCount);
            await memberCountChannel.setName(channelName);

        } catch (error) {
            console.error('Error updating member count:', error);
        }
    }
};